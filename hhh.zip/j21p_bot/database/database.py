"""Asynchronous SQLite layer (aiosqlite) for the J21P 1v1 & Tournament bot.

Design notes
  * One connection, one asyncio lock: every operation (read or write) runs under the lock, and
    multi-statement changes run inside a transaction that is committed or rolled back as a unit.
  * WAL journal, busy timeout, schema versioning (PRAGMA user_version) with in-place migrations.
  * On start-up the file is integrity-checked. A damaged file is moved aside and the newest good
    backup (if any) is restored, so a bad disk never leaves the bot crash-looping.
  * Consistent snapshots with VACUUM INTO (`backup()`), pruned to the newest N.
"""
from __future__ import annotations

import asyncio
import contextlib
import logging
import secrets
import shutil
import sqlite3
import time
from pathlib import Path
from typing import Any, AsyncIterator, Iterable

import aiosqlite

log = logging.getLogger("j21p.db")

SCHEMA_VERSION = 2

SCHEMA = """
CREATE TABLE IF NOT EXISTS players (
    discord_id    INTEGER PRIMARY KEY,
    username      TEXT    NOT NULL,
    team_ovr      INTEGER NOT NULL DEFAULT 0,
    pts           INTEGER NOT NULL DEFAULT 0,   -- ladder points
    wins          INTEGER NOT NULL DEFAULT 0,   -- ladder wins
    losses        INTEGER NOT NULL DEFAULT 0,   -- ladder losses
    goals         INTEGER NOT NULL DEFAULT 0,   -- ladder goal difference (G)
    stage         TEXT    NOT NULL DEFAULT 'registered',  -- registered|group|qualified|R16|QF|SF|F|champion
    group_name    TEXT,                          -- 'A'..'H'
    eliminated    INTEGER NOT NULL DEFAULT 0,
    group_pts     INTEGER NOT NULL DEFAULT 0,
    group_w       INTEGER NOT NULL DEFAULT 0,
    group_l       INTEGER NOT NULL DEFAULT 0,
    group_gf      INTEGER NOT NULL DEFAULT 0,
    group_ga      INTEGER NOT NULL DEFAULT 0,
    source        TEXT    NOT NULL DEFAULT 'register',   -- register | import
    registered_at TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TEXT
);

CREATE TABLE IF NOT EXISTS matches (
    id                TEXT PRIMARY KEY,           -- 8 char uppercase hex, e.g. 37FE4BD4
    guild_id          INTEGER,
    player1_id        INTEGER NOT NULL,
    player2_id        INTEGER NOT NULL,
    creator_id        INTEGER,                    -- who should create the FC Mobile room
    match_type        TEXT    NOT NULL,           -- ladder | group | knockout
    round_name        TEXT,
    bracket_round     TEXT,                       -- R16|QF|SF|F (knockout only)
    bracket_idx       INTEGER,
    thread_id         INTEGER,
    match_code        TEXT,
    reported_score    TEXT,
    p1_score          INTEGER,
    p2_score          INTEGER,
    reporter_id       INTEGER,
    screenshot_url    TEXT,
    screenshot_path   TEXT,
    p1_confirmed      INTEGER NOT NULL DEFAULT 0,
    p2_confirmed      INTEGER NOT NULL DEFAULT 0,
    ocr_confidence    REAL,
    ocr_score         TEXT,
    status            TEXT    NOT NULL DEFAULT 'pending',  -- pending|awaiting_admin|completed|voided
    cancel_p1         INTEGER NOT NULL DEFAULT 0,  -- player 1 asked to leave / void
    cancel_p2         INTEGER NOT NULL DEFAULT 0,
    verify_message_id INTEGER,
    admin_message_id  INTEGER,
    created_ts        REAL,
    code_ts           REAL,                        -- when the first room code was posted
    reminders_sent    TEXT    NOT NULL DEFAULT '',
    created_at        TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at      TEXT
);

CREATE TABLE IF NOT EXISTS queue (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    discord_id INTEGER NOT NULL UNIQUE,
    joined_at  TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT
);

-- 16-player single-elimination Best-of-3 bracket: R16 (8), QF (4), SF (2), F (1)
CREATE TABLE IF NOT EXISTS bracket (
    rnd      TEXT    NOT NULL,
    idx      INTEGER NOT NULL,
    p1       INTEGER,
    p2       INTEGER,
    p1_wins  INTEGER NOT NULL DEFAULT 0,
    p2_wins  INTEGER NOT NULL DEFAULT 0,
    winner   INTEGER,
    state    TEXT    NOT NULL DEFAULT 'waiting',   -- waiting|live|done|dead
    match_id TEXT,
    PRIMARY KEY (rnd, idx)
);

CREATE TABLE IF NOT EXISTS match_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    match_id   TEXT,
    text       TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""

INDEXES = (
    "CREATE INDEX IF NOT EXISTS idx_matches_thread ON matches(thread_id)",
    "CREATE INDEX IF NOT EXISTS idx_matches_admin  ON matches(admin_message_id)",
    "CREATE INDEX IF NOT EXISTS idx_matches_status ON matches(status, match_type)",
    "CREATE INDEX IF NOT EXISTS idx_matches_players ON matches(player1_id, player2_id)",
    "CREATE INDEX IF NOT EXISTS idx_players_group ON players(group_name)",
    "CREATE INDEX IF NOT EXISTS idx_log_match ON match_log(match_id)",
)
UNIQUE_USERNAME_INDEX = "CREATE UNIQUE INDEX IF NOT EXISTS idx_players_username ON players(username COLLATE NOCASE)"

PLAYER_COLS = {
    "username", "team_ovr", "pts", "wins", "losses", "goals", "stage", "group_name", "eliminated",
    "group_pts", "group_w", "group_l", "group_gf", "group_ga", "source",
}
MATCH_COLS = {
    "guild_id", "creator_id", "round_name", "bracket_round", "bracket_idx", "thread_id", "match_code",
    "reported_score", "p1_score", "p2_score", "reporter_id", "screenshot_url", "screenshot_path",
    "p1_confirmed", "p2_confirmed", "ocr_confidence", "ocr_score", "status", "cancel_p1",
    "cancel_p2", "verify_message_id", "admin_message_id", "code_ts", "reminders_sent", "completed_at",
}
BRACKET_COLS = {"p1", "p2", "p1_wins", "p2_wins", "winner", "state", "match_id"}
CONFIRM_COLS = {"p1_confirmed", "p2_confirmed"}

ACTIVE_STATUSES = ("pending", "awaiting_admin")
MAX_LOG_ROWS = 5000


class UsernameTaken(Exception):
    """The FC Mobile username already belongs to another Discord account."""

    def __init__(self, owner_id: int | None):
        super().__init__(f"username taken by {owner_id}")
        self.owner_id = owner_id


# ---------------------------------------------------------------------------------------
# File-level checks (run before the connection is opened)
# ---------------------------------------------------------------------------------------
def _quick_check(path: Path) -> bool:
    try:
        con = sqlite3.connect(path)
        try:
            row = con.execute("PRAGMA quick_check").fetchone()
        finally:
            con.close()
        return bool(row) and row[0] == "ok"
    except sqlite3.Error:
        return False


def _check_and_repair(path: Path, backup_dir: Path | None) -> tuple[Path | None, Path | None]:
    """Returns (corrupt file moved aside, backup restored). Both None when the file is healthy."""
    if not path.exists() or path.stat().st_size == 0 or _quick_check(path):
        return None, None
    corrupt = path.with_name(f"{path.name}.corrupt-{int(time.time())}")
    path.rename(corrupt)
    for suffix in ("-wal", "-shm"):
        sidecar = path.with_name(path.name + suffix)
        if sidecar.exists():
            sidecar.unlink()
    if backup_dir and backup_dir.exists():
        for backup in sorted(backup_dir.glob("j21p-*.sqlite3"), reverse=True):
            if _quick_check(backup):
                shutil.copy2(backup, path)
                return corrupt, backup
    return corrupt, None


def _backup_old_schema(path: Path) -> Path | None:
    """Early builds used integer match IDs. Move such a database aside instead of corrupting it."""
    if not path.exists():
        return None
    try:
        con = sqlite3.connect(path)
        try:
            cols = con.execute("PRAGMA table_info(matches)").fetchall()
        finally:
            con.close()
    except sqlite3.Error:
        return None
    if cols and cols[0][1] == "id" and cols[0][2].upper() == "INTEGER":
        backup = path.with_name(f"{path.name}.old-{int(time.time())}")
        path.rename(backup)
        for suffix in ("-wal", "-shm"):
            sidecar = path.with_name(path.name + suffix)
            if sidecar.exists():
                sidecar.unlink()
        return backup
    return None


class Database:
    def __init__(self, path: str | Path, backup_dir: str | Path | None = None):
        self.path = Path(path)
        self.backup_dir = Path(backup_dir) if backup_dir else None
        self.conn: aiosqlite.Connection | None = None
        self._lock = asyncio.Lock()
        self.migrated_from: Path | None = None   # old-layout database moved aside
        self.corrupt_moved: Path | None = None   # damaged database moved aside
        self.restored_from: Path | None = None   # backup restored after corruption

    # ------------------------------------------------------------------ core
    async def connect(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.corrupt_moved, self.restored_from = await asyncio.to_thread(
            _check_and_repair, self.path, self.backup_dir
        )
        self.migrated_from = await asyncio.to_thread(_backup_old_schema, self.path)
        self.conn = await aiosqlite.connect(self.path)
        self.conn.row_factory = aiosqlite.Row
        for pragma in ("journal_mode=WAL", "synchronous=NORMAL", "busy_timeout=5000"):
            await self.conn.execute(f"PRAGMA {pragma}")
        await self._migrate()

    async def close(self) -> None:
        if self.conn:
            conn, self.conn = self.conn, None
            try:
                await conn.commit()
            except Exception:
                pass
            await conn.close()

    async def _columns(self, table: str) -> set[str]:
        async with self.conn.execute(f"PRAGMA table_info({table})") as cur:
            return {row["name"] for row in await cur.fetchall()}

    async def _migrate(self) -> None:
        async with self._lock:
            async with self.conn.execute("PRAGMA user_version") as cur:
                version = (await cur.fetchone())[0]
            await self.conn.executescript(SCHEMA)
            # databases from before a column existed
            for table, column, ddl in (
                ("players", "team_ovr", "INTEGER NOT NULL DEFAULT 0"),
                ("players", "source", "TEXT NOT NULL DEFAULT 'register'"),
                ("players", "updated_at", "TEXT"),
            ):
                if column not in await self._columns(table):
                    await self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")
            for statement in INDEXES:
                await self.conn.execute(statement)
            try:
                await self.conn.execute(UNIQUE_USERNAME_INDEX)
            except sqlite3.IntegrityError:
                log.warning("Duplicate FC usernames already exist; uniqueness is enforced in code only")
            if version < SCHEMA_VERSION:
                await self.conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
                log.info("Database schema upgraded %s -> %s", version, SCHEMA_VERSION)
            await self.conn.commit()

    @contextlib.asynccontextmanager
    async def _tx(self) -> AsyncIterator[aiosqlite.Connection]:
        """Exclusive access plus a transaction: committed on success, rolled back on any error."""
        async with self._lock:
            try:
                yield self.conn
                await self.conn.commit()
            except BaseException:
                with contextlib.suppress(Exception):
                    await self.conn.rollback()
                raise

    async def _run(self, sql: str, params: Iterable[Any] = ()) -> tuple[int, int]:
        """Execute one write statement. Returns (rowcount, lastrowid)."""
        async with self._tx() as conn:
            cur = await conn.execute(sql, tuple(params))
            result = (cur.rowcount, cur.lastrowid)
            await cur.close()
        return result

    async def _one(self, sql: str, params: Iterable[Any] = ()) -> dict | None:
        async with self._lock:
            async with self.conn.execute(sql, tuple(params)) as cur:
                row = await cur.fetchone()
        return dict(row) if row else None

    async def _all(self, sql: str, params: Iterable[Any] = ()) -> list[dict]:
        async with self._lock:
            async with self.conn.execute(sql, tuple(params)) as cur:
                rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def _update(self, table: str, where: str, where_params: Iterable[Any],
                      fields: dict[str, Any], allowed: set[str]) -> None:
        if not fields:
            return
        bad = set(fields) - allowed
        if bad:
            raise ValueError(f"Unknown {table} column(s): {', '.join(sorted(bad))}")
        sets = ", ".join(f"{k}=?" for k in fields)
        await self._run(f"UPDATE {table} SET {sets} WHERE {where}", (*fields.values(), *where_params))

    # ---------------------------------------------------------- maintenance
    async def backup(self, keep: int = 20) -> Path:
        """Write a consistent snapshot into the backup folder and prune the oldest ones."""
        if not self.backup_dir:
            raise RuntimeError("No backup directory configured")
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        target = self.backup_dir / f"j21p-{stamp}.sqlite3"
        n = 1
        while target.exists():
            n += 1
            target = self.backup_dir / f"j21p-{stamp}-{n}.sqlite3"
        literal = str(target).replace("'", "''")
        async with self._lock:
            await self.conn.commit()
            cur = await self.conn.execute(f"VACUUM INTO '{literal}'")
            await cur.close()
        existing = sorted(self.backup_dir.glob("j21p-*.sqlite3"))
        for old in existing[: max(0, len(existing) - max(1, keep))]:
            with contextlib.suppress(OSError):
                old.unlink()
        return target

    async def stats(self) -> dict[str, int]:
        out = {"players": 0, "queue": 0, "pending": 0, "awaiting_admin": 0, "completed": 0, "voided": 0}
        out["players"] = (await self._one("SELECT COUNT(*) AS n FROM players"))["n"]
        out["queue"] = (await self._one("SELECT COUNT(*) AS n FROM queue"))["n"]
        for row in await self._all("SELECT status, COUNT(*) AS n FROM matches GROUP BY status"):
            out[row["status"]] = row["n"]
        return out

    # -------------------------------------------------------------- settings
    async def get_setting(self, key: str, default: str | None = None) -> str | None:
        row = await self._one("SELECT value FROM settings WHERE key=?", (key,))
        return row["value"] if row and row["value"] is not None else default

    async def set_setting(self, key: str, value: str | None) -> None:
        await self._run(
            "INSERT INTO settings(key, value) VALUES(?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )

    # --------------------------------------------------------------- players
    async def upsert_player(self, discord_id: int, username: str, team_ovr: int | None = None,
                            source: str = "register") -> str:
        """Create or update a player. team_ovr=None keeps the stored OVR.

        Returns "created", "updated" or "unchanged". Raises UsernameTaken when another account
        already uses that FC username (case-insensitive).
        """
        async with self._tx() as conn:
            async with conn.execute(
                "SELECT discord_id FROM players WHERE username = ? COLLATE NOCASE AND discord_id <> ?",
                (username, discord_id),
            ) as cur:
                clash = await cur.fetchone()
            if clash:
                raise UsernameTaken(clash["discord_id"])
            async with conn.execute("SELECT username, team_ovr FROM players WHERE discord_id=?", (discord_id,)) as cur:
                existing = await cur.fetchone()
            if existing is None:
                await conn.execute(
                    "INSERT INTO players(discord_id, username, team_ovr, source, updated_at) "
                    "VALUES(?, ?, ?, ?, CURRENT_TIMESTAMP)",
                    (discord_id, username, team_ovr or 0, source),
                )
                return "created"
            ovr = existing["team_ovr"] if team_ovr is None else team_ovr
            if existing["username"] == username and existing["team_ovr"] == ovr:
                return "unchanged"
            await conn.execute(
                "UPDATE players SET username=?, team_ovr=?, updated_at=CURRENT_TIMESTAMP WHERE discord_id=?",
                (username, ovr, discord_id),
            )
            return "updated"

    async def get_player(self, discord_id: int) -> dict | None:
        return await self._one("SELECT * FROM players WHERE discord_id=?", (discord_id,))

    async def find_player_by_username(self, username: str) -> dict | None:
        return await self._one("SELECT * FROM players WHERE username = ? COLLATE NOCASE", (username,))

    async def list_players(self) -> list[dict]:
        return await self._all("SELECT * FROM players ORDER BY registered_at, discord_id")

    async def count_players(self) -> int:
        return (await self._one("SELECT COUNT(*) AS n FROM players"))["n"]

    async def update_player(self, discord_id: int, **fields: Any) -> None:
        await self._update("players", "discord_id=?", (discord_id,), fields, PLAYER_COLS)

    async def ladder_top(self, limit: int = 20) -> list[dict]:
        """Only players with at least one ladder game, so tournament-only players don't flood it."""
        return await self._all(
            "SELECT * FROM players WHERE wins + losses > 0 "
            "ORDER BY pts DESC, goals DESC, wins DESC, username COLLATE NOCASE LIMIT ?",
            (limit,),
        )

    async def player_rank(self, discord_id: int) -> tuple[int, int] | None:
        """(ladder rank, ranked players) or None when the player has no ladder games yet."""
        rows = await self._all(
            "SELECT discord_id FROM players WHERE wins + losses > 0 "
            "ORDER BY pts DESC, goals DESC, wins DESC, username COLLATE NOCASE"
        )
        ids = [r["discord_id"] for r in rows]
        return (ids.index(discord_id) + 1, len(ids)) if discord_id in ids else None

    async def add_ladder_result(self, winner_id: int, loser_id: int, points: int,
                                winner_goals: int, loser_goals: int) -> None:
        diff = winner_goals - loser_goals
        async with self._tx() as conn:
            await conn.execute(
                "UPDATE players SET pts=pts+?, wins=wins+1, goals=goals+? WHERE discord_id=?",
                (points, diff, winner_id),
            )
            await conn.execute(
                "UPDATE players SET losses=losses+1, goals=goals-? WHERE discord_id=?",
                (diff, loser_id),
            )

    async def add_group_result(self, winner_id: int, loser_id: int, points: int,
                               winner_goals: int, loser_goals: int) -> None:
        async with self._tx() as conn:
            await conn.execute(
                "UPDATE players SET group_pts=group_pts+?, group_w=group_w+1, "
                "group_gf=group_gf+?, group_ga=group_ga+? WHERE discord_id=?",
                (points, winner_goals, loser_goals, winner_id),
            )
            await conn.execute(
                "UPDATE players SET group_l=group_l+1, group_gf=group_gf+?, group_ga=group_ga+? "
                "WHERE discord_id=?",
                (loser_goals, winner_goals, loser_id),
            )

    async def grouped_players(self) -> list[dict]:
        return await self._all("SELECT * FROM players WHERE group_name IS NOT NULL")

    # ----------------------------------------------------------------- queue
    async def queue_add(self, discord_id: int) -> bool:
        rowcount, _ = await self._run("INSERT OR IGNORE INTO queue(discord_id) VALUES(?)", (discord_id,))
        return rowcount == 1

    async def queue_remove(self, discord_id: int) -> bool:
        rowcount, _ = await self._run("DELETE FROM queue WHERE discord_id=?", (discord_id,))
        return rowcount == 1

    async def queue_list(self) -> list[int]:
        rows = await self._all("SELECT discord_id FROM queue ORDER BY id")
        return [r["discord_id"] for r in rows]

    async def queue_purge_stale(self, minutes: int) -> list[int]:
        """Drop players who have waited longer than `minutes`. Returns their IDs."""
        async with self._tx() as conn:
            async with conn.execute(
                "SELECT discord_id FROM queue WHERE joined_at < datetime('now', ?)", (f"-{int(minutes)} minutes",)
            ) as cur:
                ids = [r["discord_id"] for r in await cur.fetchall()]
            if ids:
                await conn.execute(
                    "DELETE FROM queue WHERE joined_at < datetime('now', ?)", (f"-{int(minutes)} minutes",)
                )
        return ids

    # --------------------------------------------------------------- matches
    async def create_match(self, player1_id: int, player2_id: int, match_type: str, *,
                           round_name: str | None = None, bracket_round: str | None = None,
                           bracket_idx: int | None = None, guild_id: int | None = None) -> str:
        """Insert a match with a fresh 8 char hex ID and return that ID."""
        for _ in range(10):
            match_id = secrets.token_hex(4).upper()
            try:
                await self._run(
                    "INSERT INTO matches(id, player1_id, player2_id, creator_id, match_type, round_name, "
                    "bracket_round, bracket_idx, guild_id, created_ts) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (match_id, player1_id, player2_id, player1_id, match_type, round_name,
                     bracket_round, bracket_idx, guild_id, time.time()),
                )
                return match_id
            except sqlite3.IntegrityError:
                continue
        raise RuntimeError("Could not generate a unique match ID")

    async def get_match(self, match_id: str) -> dict | None:
        return await self._one("SELECT * FROM matches WHERE id=?", (match_id,))

    async def get_match_by_thread(self, thread_id: int) -> dict | None:
        return await self._one(
            "SELECT * FROM matches WHERE thread_id=? ORDER BY rowid DESC LIMIT 1", (thread_id,)
        )

    async def get_match_by_admin_msg(self, message_id: int) -> dict | None:
        return await self._one("SELECT * FROM matches WHERE admin_message_id=?", (message_id,))

    async def update_match(self, match_id: str, **fields: Any) -> None:
        await self._update("matches", "id=?", (match_id,), fields, MATCH_COLS)

    async def delete_match(self, match_id: str) -> None:
        await self._run("DELETE FROM matches WHERE id=?", (match_id,))

    async def claim_completion(self, match_id: str, *, allow_voided: bool = False) -> bool:
        """Atomically mark a match completed. Returns False if someone else already did."""
        statuses = "('pending', 'awaiting_admin', 'voided')" if allow_voided else "('pending', 'awaiting_admin')"
        rowcount, _ = await self._run(
            "UPDATE matches SET status='completed', completed_at=CURRENT_TIMESTAMP "
            f"WHERE id=? AND status IN {statuses}",
            (match_id,),
        )
        return rowcount == 1

    async def claim_confirmation(self, match_id: str, column: str) -> bool:
        """Set p1_confirmed / p2_confirmed once. False if it was already set (double click)."""
        if column not in CONFIRM_COLS:
            raise ValueError(column)
        rowcount, _ = await self._run(
            f"UPDATE matches SET {column}=1 WHERE id=? AND {column}=0 AND status='pending' "
            "AND reported_score IS NOT NULL",
            (match_id,),
        )
        return rowcount == 1

    async def list_matches(self, *, statuses: Iterable[str] | None = None,
                           match_type: str | None = None, limit: int | None = None) -> list[dict]:
        sql, params, where = "SELECT * FROM matches", [], []
        if statuses:
            statuses = list(statuses)
            where.append(f"status IN ({','.join('?' * len(statuses))})")
            params += statuses
        if match_type:
            where.append("match_type=?")
            params.append(match_type)
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY rowid"
        if limit:
            sql += " LIMIT ?"
            params.append(limit)
        return await self._all(sql, params)

    async def count_matches(self, *, statuses: Iterable[str], match_type: str | None = None) -> int:
        statuses = list(statuses)
        sql = f"SELECT COUNT(*) AS n FROM matches WHERE status IN ({','.join('?' * len(statuses))})"
        params: list[Any] = list(statuses)
        if match_type:
            sql += " AND match_type=?"
            params.append(match_type)
        return (await self._one(sql, params))["n"]

    async def player_active_matches(self, discord_id: int, match_type: str | None = None) -> list[dict]:
        sql = ("SELECT * FROM matches WHERE (player1_id=? OR player2_id=?) "
               "AND status IN ('pending', 'awaiting_admin')")
        params: list[Any] = [discord_id, discord_id]
        if match_type:
            sql += " AND match_type=?"
            params.append(match_type)
        return await self._all(sql + " ORDER BY rowid", params)

    async def matches_without_thread(self) -> list[dict]:
        return await self._all(
            "SELECT * FROM matches WHERE thread_id IS NULL AND status='pending' ORDER BY rowid"
        )

    async def timer_matches(self) -> list[dict]:
        """Open matches that have a thread; the timer loop checks these every minute."""
        return await self._all(
            "SELECT * FROM matches WHERE status='pending' AND thread_id IS NOT NULL ORDER BY rowid"
        )

    async def old_screenshot_paths(self) -> list[str]:
        rows = await self._all("SELECT screenshot_path FROM matches WHERE screenshot_path IS NOT NULL")
        return [r["screenshot_path"] for r in rows]

    # ------------------------------------------------------------------- log
    async def add_log(self, match_id: str | None, text: str) -> None:
        async with self._tx() as conn:
            await conn.execute("INSERT INTO match_log(match_id, text) VALUES(?, ?)", (match_id, text[:500]))
            await conn.execute(
                "DELETE FROM match_log WHERE id <= (SELECT MAX(id) FROM match_log) - ?", (MAX_LOG_ROWS,)
            )

    async def recent_logs(self, limit: int = 15) -> list[dict]:
        return await self._all("SELECT * FROM match_log ORDER BY id DESC LIMIT ?", (limit,))

    # --------------------------------------------------------------- bracket
    async def bracket_init(self, slots: list[dict]) -> None:
        async with self._tx() as conn:
            await conn.execute("DELETE FROM bracket")
            for s in slots:
                await conn.execute(
                    "INSERT INTO bracket(rnd, idx, p1, p2, state) VALUES(?, ?, ?, ?, ?)",
                    (s["rnd"], s["idx"], s.get("p1"), s.get("p2"), s.get("state", "waiting")),
                )

    async def bracket_get(self, rnd: str, idx: int) -> dict | None:
        return await self._one("SELECT * FROM bracket WHERE rnd=? AND idx=?", (rnd, idx))

    async def bracket_all(self) -> list[dict]:
        return await self._all("SELECT * FROM bracket ORDER BY rnd, idx")

    async def bracket_update(self, rnd: str, idx: int, **fields: Any) -> None:
        await self._update("bracket", "rnd=? AND idx=?", (rnd, idx), fields, BRACKET_COLS)

    # ----------------------------------------------------------------- reset
    async def wipe_tournament(self) -> None:
        """Fresh Start: remove all tournament data but keep registrations and the ladder."""
        async with self._tx() as conn:
            await conn.execute("DELETE FROM matches WHERE match_type IN ('group', 'knockout')")
            await conn.execute("DELETE FROM bracket")
            await conn.execute(
                "UPDATE players SET stage='registered', group_name=NULL, eliminated=0, "
                "group_pts=0, group_w=0, group_l=0, group_gf=0, group_ga=0"
            )
            await conn.execute(
                "DELETE FROM settings WHERE key IN ('tournament_state', 'champion', 'group_complete_notified')"
            )
