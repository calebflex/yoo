"""Role tiers and Discord lookups.

Tiers are cumulative: executive > event manager > moderation. The server owner and anyone with
the Administrator permission count as executive so nobody can lock themselves out.
"""
from __future__ import annotations

import discord

import config


def _has(member, role_ids: frozenset[int]) -> bool:
    if not isinstance(member, discord.Member):
        return False
    if member.id == member.guild.owner_id or member.guild_permissions.administrator:
        return True
    return any(role.id in role_ids for role in member.roles)


def is_executive_member(member) -> bool:
    return _has(member, config.EXECUTIVE_ROLE_IDS)


def is_event_manager_member(member) -> bool:
    return _has(member, config.EVENT_MANAGER_ROLE_IDS)


def is_moderator_member(member) -> bool:
    return _has(member, config.MODERATION_ROLE_IDS)


def is_executive(interaction: discord.Interaction) -> bool:
    return is_executive_member(interaction.user)


def is_event_manager(interaction: discord.Interaction) -> bool:
    return is_event_manager_member(interaction.user)


def is_moderator(interaction: discord.Interaction) -> bool:
    return is_moderator_member(interaction.user)


def tier_name(member) -> str:
    if is_executive_member(member):
        return "Executive"
    if is_event_manager_member(member):
        return "Event Manager"
    if is_moderator_member(member):
        return "Moderation"
    return "Player"


def staff_mention(guild: discord.Guild | None) -> str:
    """Staff Team role mention, or @here when the role isn't in this server."""
    if guild is not None and guild.get_role(config.ROLE_STAFF_TEAM):
        return f"<@&{config.ROLE_STAFF_TEAM}>"
    return "@here"


def _find_channel(guild: discord.Guild | None, channel_id: int | None, name: str):
    if guild is None:
        return None
    if channel_id:
        channel = guild.get_channel(channel_id)
        if isinstance(channel, discord.TextChannel):
            return channel
    return discord.utils.get(guild.text_channels, name=name)


def get_admin_channel(guild: discord.Guild | None) -> discord.TextChannel | None:
    return _find_channel(guild, config.ADMIN_VERIFICATION_CHANNEL_ID, config.ADMIN_VERIFICATION_CHANNEL_NAME)


def get_alerts_channel(guild: discord.Guild | None) -> discord.TextChannel | None:
    return _find_channel(guild, config.COACH_ALERTS_CHANNEL_ID, config.COACH_ALERTS_CHANNEL_NAME)
