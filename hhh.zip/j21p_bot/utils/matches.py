"""Match lifecycle: threads, room codes, timers, score reports, OCR decision, admin queue,
moderator requests (#coach-alerts), voids and finalizing results."""
from __future__ import annotations

import asyncio
import datetime as dt
import logging
import re
import time
from pathlib import Path

import discord

import config
from utils import ocr
from utils.checks import get_admin_channel, get_alerts_channel, staff_mention

log = logging.getLogger("j21p.matches")

TYPE_LABELS = {"ladder": "1v1 Ladder", "group": "Group Stage", "knockout": "Knockout (Best of 3)"}
CLOSED_STATUSES = ("completed", "voided")
CODE_RE = re.compile(r"^\d{6}$")
MATCH_ID_RE = re.compile(r"\b[0-9A-F]{8}\b")

# Exact opening message for every match thread.
MATCH_START_TEXT = (
    "Match Started\n\n"
    "**{p1} ({o1} OVR) vs {p2} ({o2} OVR)**\n\n"
    "Paste your **6-digit room code** here!\n"
    "Winner: Click **Report Score** + upload screenshot\n"
    "Need help? Click **Call Admin / Dispute**\n\n"
    "Good luck!"
)


class MatchError(Exception):
    """A problem that should be shown to the user as-is."""


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------
def brand_embed(title: str, description: str | None = None, color: int | None = None) -> discord.Embed:
    embed = discord.Embed(title=title, description=description, color=color or config.BRAND_COLOR)
    embed.set_footer(text=config.BRAND_FOOTER)
    return embed


def opponent_of(m: dict, user_id: int) -> int:
    return m["player2_id"] if user_id == m["player1_id"] else m["player1_id"]


def winner_loser(m: dict) -> tuple[int, int, int, int]:
    """Returns (winner_id, loser_id, winner_score, loser_score) from a scored match."""
    if m["p1_score"] > m["p2_score"]:
        return m["player1_id"], m["player2_id"], m["p1_score"], m["p2_score"]
    return m["player2_id"], m["player1_id"], m["p2_score"], m["p1_score"]


def reporter_scores(m: dict) -> tuple[int, int]:
    """(reporter's score, opponent's score) - the order the reporter's own screenshot should show."""
    if m["reporter_id"] == m["player2_id"]:
        return m["p2_score"], m["p1_score"]
    return m["p1_score"], m["p2_score"]


def utc_now_sql() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def validate_score(match_type: str, a: int, b: int) -> str | None:
    """Returns an error message, or None when the score is valid."""
    if a < 0 or b < 0:
        return "Scores can't be negative."
    if a == b:
        return "Draws aren't allowed. A winner must be decided (extra time/penalties), or call an admin."
    if match_type == "knockout":
        if max(a, b) != 2 or min(a, b) not in (0, 1):
            return "A Best-of-3 series must finish **2-0** or **2-1** (games won by each player)."
    elif max(a, b) > 30:
        return "That score looks unrealistic, please double check it."
    return None


# ---------------------------------------------------------------------------
# Lookups
# ---------------------------------------------------------------------------
async def get_hub_channel(bot) -> discord.TextChannel:
    raw = await bot.db.get_setting("hub_channel_id")
    channel_id = int(raw) if raw and raw.isdigit() else config.MATCH_CHANNEL_ID
    if not channel_id:
        raise MatchError("No hub channel is set yet. An executive needs to run **/player_hub** in the hub channel first.")
    channel = bot.get_channel(channel_id)
    if channel is None:
        try:
            channel = await bot.fetch_channel(channel_id)
        except discord.HTTPException:
            raise MatchError("I can't find the hub channel any more. Run **/player_hub** again.")
    if not isinstance(channel, discord.TextChannel):
        raise MatchError("The hub channel must be a normal text channel.")
    return channel


async def get_thread(bot, thread_id: int | None) -> discord.Thread | None:
    if not thread_id:
        return None
    channel = bot.get_channel(thread_id)
    if channel is None:
        try:
            channel = await bot.fetch_channel(thread_id)
        except discord.HTTPException:
            return None
    return channel if isinstance(channel, discord.Thread) else None


async def guild_for(bot, m: dict) -> discord.Guild | None:
    if m.get("guild_id"):
        guild = bot.get_guild(m["guild_id"])
        if guild:
            return guild
    try:
        return (await get_hub_channel(bot)).guild
    except MatchError:
        return bot.guilds[0] if bot.guilds else None


async def announce(bot, text: str | None = None, embed: discord.Embed | None = None) -> None:
    """Post to the hub channel (best effort)."""
    try:
        channel = await get_hub_channel(bot)
        await channel.send(content=text, embed=embed)
    except (MatchError, discord.HTTPException):
        log.warning("Could not announce: %s", text)


async def lock_thread(thread: discord.Thread) -> None:
    try:
        await thread.edit(archived=True, locked=True)
    except discord.HTTPException:
        log.warning("Could not archive/lock thread %s", thread.id)


# ---------------------------------------------------------------------------
# Creating matches and threads
# ---------------------------------------------------------------------------
def thread_name(p1: dict, p2: dict) -> str:
    """match-{p1}-{p2}, so nobody confuses it with the 6-digit FC Mobile room code."""
    return re.sub(r"\s+", "-", f"match-{p1['username']}-{p2['username']}".strip())[:100]


def timer_notice(m: dict, now: float | None = None) -> str:
    """The timer message posted under the opening message."""
    created = int(m.get("created_ts") or now or time.time())
    if m["match_type"] == "ladder":
        deadline = created + config.QUEUE_CREATOR_MINUTES * 60
        return (
            f"<@{m['creator_id']}> you are the match creator. Create the FC Mobile private match and paste the "
            f"6-digit room code here within **{config.QUEUE_CREATOR_MINUTES} minutes** (<t:{deadline}:R>), "
            f"or this match may be forfeited or voided.\nMatch ID: `{m['id']}`"
        )
    deadline = created + config.TOURNAMENT_TOTAL_HOURS * 3600
    return (
        f"Tournament timer: you have **{config.TOURNAMENT_TOTAL_HOURS} hours** from now to get this match done "
        f"(<t:{deadline}:R>). Once either player posts the 6-digit room code, a "
        f"**{config.TOURNAMENT_ACTIVE_HOURS}-hour active timer** starts to finish it. "
        f"I'll ping you with reminders.\nMatch ID: `{m['id']}`"
    )


async def open_thread(bot, match_id: str) -> discord.Thread:
    """Create the private thread for a match row, add both players and post the opening message."""
    from cogs.match_thread import MatchControlView  # local import: the cog imports this module

    db = bot.db
    m = await db.get_match(match_id)
    if not m:
        raise MatchError("That match no longer exists.")
    existing = await get_thread(bot, m["thread_id"])
    if existing:
        return existing

    p1, p2 = await db.get_player(m["player1_id"]), await db.get_player(m["player2_id"])
    if not p1 or not p2:
        raise MatchError("Both players must be registered.")

    channel = await get_hub_channel(bot)
    guild = channel.guild
    try:
        thread = await channel.create_thread(
            name=thread_name(p1, p2),
            type=discord.ChannelType.private_thread,
            invitable=False,
            auto_archive_duration=10080,
            reason=f"J21P match {match_id}",
        )
    except discord.Forbidden:
        raise MatchError(
            f"I need **Create Private Threads**, **Send Messages in Threads** and **Manage Threads** in {channel.mention}."
        )
    except discord.HTTPException as exc:
        raise MatchError(f"Discord refused to create the thread: {exc}")

    missing = []
    for uid in (m["player1_id"], m["player2_id"]):
        member = guild.get_member(uid)
        if member is None:
            try:
                member = await guild.fetch_member(uid)
            except discord.HTTPException:
                missing.append(uid)
                continue
        try:
            await thread.add_user(member)
        except discord.HTTPException:
            missing.append(uid)
    if missing:
        try:
            await thread.delete()
        except discord.HTTPException:
            pass
        raise MatchError(
            "Couldn't add " + ", ".join(f"<@{u}>" for u in missing) + " to the thread. Are they still in the server?"
        )

    await db.update_match(match_id, thread_id=thread.id, guild_id=guild.id)
    m = await db.get_match(match_id)
    await thread.send(
        MATCH_START_TEXT.format(p1=p1["username"], o1=p1["team_ovr"], p2=p2["username"], o2=p2["team_ovr"]),
        view=MatchControlView(bot),
    )
    await thread.send(timer_notice(m))
    await db.add_log(match_id, f"Thread opened for {p1['username']} vs {p2['username']} ({m['match_type']})")
    return thread


async def create_match(bot, p1_id: int, p2_id: int, match_type: str, *, round_name: str | None = None,
                       bracket_round: str | None = None, bracket_idx: int | None = None,
                       open_now: bool = True) -> str:
    db = bot.db
    if p1_id == p2_id:
        raise MatchError("A player can't play themselves.")
    for uid in (p1_id, p2_id):
        if not await db.get_player(uid):
            raise MatchError(f"<@{uid}> isn't registered yet.")
    match_id = await db.create_match(
        p1_id, p2_id, match_type, round_name=round_name,
        bracket_round=bracket_round, bracket_idx=bracket_idx,
    )
    if open_now:
        try:
            await open_thread(bot, match_id)
        except Exception:
            await db.delete_match(match_id)
            raise
    return match_id


# ---------------------------------------------------------------------------
# Room codes and timers
# ---------------------------------------------------------------------------
async def record_code(bot, m: dict, code: str) -> bool:
    """Save a 6-digit room code. Returns True when this is the first code (starts the active timer)."""
    first = not m["code_ts"]
    fields = {"match_code": code}
    if first:
        fields["code_ts"] = time.time()
    await bot.db.update_match(m["id"], **fields)
    await bot.db.add_log(m["id"], "Room code recorded")
    return first


def code_recorded_text(m: dict, first: bool, opponent_id: int, now: float | None = None) -> str:
    text = f"Code recorded for match {m['id']}.\n<@{opponent_id}> you can join the room now."
    if first and m["match_type"] != "ladder":
        end = int((now or time.time()) + config.TOURNAMENT_ACTIVE_HOURS * 3600)
        text += f"\nThe **{config.TOURNAMENT_ACTIVE_HOURS}-hour active timer** has started (<t:{end}:R>)."
    return text


def timer_events(m: dict, now: float) -> list[dict]:
    """Which timer messages are due for a pending match right now.

    Returns at most one event: {"key", "kind", "mark"} where `mark` lists every reminder key to
    record as sent (so a late bot doesn't replay old reminders). kind is one of
    creator_late, remind, expired.
    """
    sent = {k for k in (m.get("reminders_sent") or "").split(",") if k}
    created = m.get("created_ts") or now
    code_ts = m.get("code_ts")

    if m["match_type"] == "ladder":
        late = (not code_ts) and now - created >= config.QUEUE_CREATOR_MINUTES * 60 and "q8" not in sent
        return [{"key": "q8", "kind": "creator_late", "mark": ["q8"]}] if late else []

    if code_ts:
        prefix, end, label = "t24", code_ts + config.TOURNAMENT_ACTIVE_HOURS * 3600, "active"
    else:
        prefix, end, label = "t48", created + config.TOURNAMENT_TOTAL_HOURS * 3600, "total"
    left = end - now
    levels = [("12h", 12 * 3600), ("2h", 2 * 3600), ("exp", 0)]
    due = [name for name, threshold in levels if left <= threshold and f"{prefix}_{name}" not in sent]
    if not due:
        return []
    pick = due[-1]
    mark = [f"{prefix}_{name}" for name, _ in levels[: [n for n, _ in levels].index(pick) + 1]]
    return [{
        "key": f"{prefix}_{pick}", "kind": "expired" if pick == "exp" else "remind",
        "mark": mark, "label": label, "end": int(end),
    }]


async def run_timer_event(bot, m: dict, event: dict) -> None:
    """Post the reminder / expiry message for one due timer event."""
    db = bot.db
    sent = [k for k in (m.get("reminders_sent") or "").split(",") if k]
    for key in event["mark"]:
        if key not in sent:
            sent.append(key)
    await db.update_match(m["id"], reminders_sent=",".join(sent))

    thread = await get_thread(bot, m["thread_id"])
    mentions = f"<@{m['player1_id']}> <@{m['player2_id']}>"
    if event["kind"] == "creator_late":
        if thread:
            await thread.send(
                f"{mentions} {config.QUEUE_CREATOR_MINUTES} minutes have passed and no room code was posted. "
                f"<@{m['creator_id']}> is the match creator. Staff have been alerted and the match may be forfeited or voided."
            )
        await create_mod_request(
            bot, m, requester=None,
            reason=f"No room code was posted within {config.QUEUE_CREATOR_MINUTES} minutes (creator: <@{m['creator_id']}>).",
        )
    elif event["kind"] == "remind":
        if thread:
            await thread.send(
                f"{mentions} reminder: the {event['label']} timer for this match ends <t:{event['end']}:R>. "
                "Finish the match and report the score, or call an admin if there's a problem."
            )
    elif event["kind"] == "expired":
        if thread:
            await thread.send(
                f"{mentions} the {event['label']} timer for this match has run out. Staff have been alerted."
            )
        hours = config.TOURNAMENT_ACTIVE_HOURS if event["label"] == "active" else config.TOURNAMENT_TOTAL_HOURS
        await create_mod_request(
            bot, m, requester=None,
            reason=f"The {hours}-hour {event['label']} timer expired without a result.",
        )
    await db.add_log(m["id"], f"Timer event: {event['key']}")


# ---------------------------------------------------------------------------
# Score reports
# ---------------------------------------------------------------------------
async def reset_report(bot, match_id: str) -> None:
    await bot.db.update_match(
        match_id, reported_score=None, p1_score=None, p2_score=None, reporter_id=None,
        screenshot_url=None, screenshot_path=None, p1_confirmed=0, p2_confirmed=0,
        ocr_confidence=None, ocr_score=None, verify_message_id=None, admin_message_id=None,
        status="pending",
    )


def report_text(m: dict, reporter_name: str, opponent_name: str) -> str:
    mine, theirs = reporter_scores(m)
    series = " (games won)" if m["match_type"] == "knockout" else ""
    return (
        f"<@{opponent_of(m, m['reporter_id'])}> <@{m['reporter_id']}> reported **{reporter_name} {mine} - {theirs} "
        f"{opponent_name}**{series}. Check the screenshot above, then confirm or dispute."
    )


async def process_confirmed(bot, match_id: str) -> None:
    """Opponent confirmed: run OCR, then auto-approve or send to the admin queue."""
    db = bot.db
    m = await db.get_match(match_id)
    thread = await get_thread(bot, m["thread_id"])
    if thread:
        await thread.send("Result confirmed. Checking the screenshot...")

    result = await asyncio.to_thread(ocr.read_score, m["screenshot_path"] or "")
    ocr_text = f"{result.score[0]}-{result.score[1]}" if result.score else None
    await db.update_match(match_id, ocr_confidence=result.confidence, ocr_score=ocr_text)
    expected = reporter_scores(m)

    reason = None
    if m["match_type"] == "knockout" and config.BO3_ALWAYS_ADMIN:
        reason = "Both players agreed on a Best-of-3 series result. Series results are always checked by staff."
    elif result.error:
        reason = f"Both players agreed, but the OCR couldn't run: {result.error}."
    elif result.score is None:
        reason = "Both players agreed, but the OCR couldn't read a scoreline from the screenshot."
    elif result.score != expected:
        reason = (
            f"Both players agreed on {expected[0]}-{expected[1]}, but the OCR read "
            f"{result.score[0]}-{result.score[1]}, which doesn't match."
        )
    elif result.confidence < config.OCR_CONFIDENCE_THRESHOLD:
        reason = "Both players agreed, but OCR confidence was too low to trust automatically."
    elif not config.AUTO_APPROVE:
        reason = "Both players agreed and the OCR matches, but automatic approval is switched off."

    if reason is None:
        await db.add_log(match_id, f"Auto-approved (OCR {ocr_text}, {result.confidence:.0f}% conf)")
        await finalize_match(bot, match_id)
        return
    await send_admin_review(bot, match_id, reason, result)


async def send_admin_review(bot, match_id: str, reason: str, result: ocr.OCRResult) -> None:
    from cogs.match_thread import AdminReviewView

    db = bot.db
    m = await db.get_match(match_id)
    p1, p2 = await db.get_player(m["player1_id"]), await db.get_player(m["player2_id"])
    thread = await get_thread(bot, m["thread_id"])
    guild = await guild_for(bot, m)
    winner_id, loser_id, ws, ls = winner_loser(m)

    ocr_line = (
        f"({result.score[0]}, {result.score[1]}) ({result.confidence:.0f}% conf)"
        if result.score else "nothing readable (0% conf)"
    )
    embed = discord.Embed(
        title="J21P Match Result Needs a Check",
        description=(
            f"**Reason:** {reason}\n"
            f"**Score:** {ws} - {ls}\n"
            f"**Winner:** <@{winner_id}>\n"
            f"**Loser:** <@{loser_id}>\n"
            f"**OCR read:** {ocr_line}"
        ),
        color=0xF5A623,
    )
    thread_ref = f"<#{m['thread_id']}>" if m["thread_id"] else "-"
    embed.add_field(
        name="Match",
        value=f"`{m['id']}` | {TYPE_LABELS.get(m['match_type'])}"
              f"{' | ' + m['round_name'] if m['round_name'] else ''}\n"
              f"{p1['username']} ({p1['team_ovr']} OVR) vs {p2['username']} ({p2['team_ovr']} OVR) | {thread_ref}",
        inline=False,
    )
    embed.set_footer(text=f"Match ID: {m['id']}")
    embed.timestamp = dt.datetime.now(dt.timezone.utc)

    file = None
    path = Path(m["screenshot_path"]) if m["screenshot_path"] else None
    if path and path.exists():
        filename = f"screenshot{path.suffix or '.png'}"
        file = discord.File(path, filename=filename)
        embed.set_image(url=f"attachment://{filename}")

    destination = get_admin_channel(guild) or thread
    if destination is None:
        raise MatchError("No admin verification channel or match thread is available.")
    kwargs = {"file": file} if file else {}
    message = await destination.send(embed=embed, view=AdminReviewView(bot), **kwargs)
    await db.update_match(match_id, status="awaiting_admin", admin_message_id=message.id)
    await db.add_log(match_id, f"Sent to admin queue: {reason}")
    if thread:
        await thread.send("Sent to staff for a quick check. You'll be notified here when it's approved.")


async def reject_result(bot, match_id: str, reason: str, staff: discord.abc.User) -> None:
    m = await bot.db.get_match(match_id)
    await reset_report(bot, match_id)
    await bot.db.add_log(match_id, f"Result rejected by {staff}: {reason}")
    thread = await get_thread(bot, m["thread_id"])
    if thread:
        await thread.send(
            f"{staff.mention} rejected the reported result.\n**Reason:** {reason}\n"
            f"<@{m['player1_id']}> <@{m['player2_id']}> press **Report Score** again with the correct score."
        )


# ---------------------------------------------------------------------------
# Moderator requests (#coach-alerts)
# ---------------------------------------------------------------------------
def alert_embed(m: dict, requester: discord.abc.User | None, reason: str, evidence: str | None = None) -> discord.Embed:
    embed = discord.Embed(title="Moderator Request", color=config.ALERT_COLOR)
    if requester is not None:
        embed.add_field(name="Requested by", value=requester.mention, inline=False)
        embed.add_field(name="Opponent", value=f"<@{opponent_of(m, requester.id)}>", inline=False)
    else:
        embed.add_field(name="Requested by", value="J21P match timer (automatic)", inline=False)
        embed.add_field(name="Players", value=f"<@{m['player1_id']}> vs <@{m['player2_id']}>", inline=False)
    embed.add_field(name="Reason", value=reason[:1000], inline=False)
    if evidence:
        embed.add_field(name="Evidence / Note", value=evidence[:1000], inline=False)
    if m.get("thread_id"):
        embed.add_field(name="Match thread", value=f"<#{m['thread_id']}>", inline=False)
    embed.set_footer(text=f"Match ID: {m['id']}")
    embed.timestamp = dt.datetime.now(dt.timezone.utc)  # Discord renders "Match ID: X • Today at 3:45 PM"
    return embed


async def create_mod_request(bot, m: dict, *, requester: discord.abc.User | None, reason: str,
                             evidence: str | None = None) -> bool:
    """Send the Moderator Request to #coach-alerts (or the match thread if the channel is missing)."""
    from cogs.match_thread import CoachAlertView

    db = bot.db
    p1, p2 = await db.get_player(m["player1_id"]), await db.get_player(m["player2_id"])
    guild = await guild_for(bot, m)
    thread = await get_thread(bot, m["thread_id"])
    destination = get_alerts_channel(guild) or thread
    if destination is None:
        log.warning("No #coach-alerts channel or thread for match %s", m["id"])
        return False
    await destination.send(
        content=staff_mention(guild),
        embed=alert_embed(m, requester, reason, evidence),
        view=CoachAlertView(bot, p1["username"], p2["username"]),
        allowed_mentions=discord.AllowedMentions(roles=True, everyone=True, users=True),
    )
    who = str(requester) if requester else "timer"
    await db.add_log(m["id"], f"Moderator request by {who}: {reason[:150]}")
    return True


# ---------------------------------------------------------------------------
# Void / award
# ---------------------------------------------------------------------------
async def void_match(bot, match_id: str, by: discord.abc.User | str) -> bool:
    """Close a match with no result. Returns False if it was already closed."""
    db = bot.db
    m = await db.get_match(match_id)
    if not m or m["status"] in CLOSED_STATUSES:
        return False
    by_text = by.mention if hasattr(by, "mention") else str(by)
    await db.update_match(match_id, status="voided", completed_at=utc_now_sql())
    await db.add_log(match_id, f"Match {match_id} voided by {by}. No result recorded.")

    thread = await get_thread(bot, m["thread_id"])
    if thread:
        await thread.send(
            f"Match {match_id} between <@{m['player1_id']}> and <@{m['player2_id']}> was voided - No result recorded."
        )
        await thread.send(f"Match voided by {by_text}. No result recorded.")
        if m["match_type"] != "ladder":
            await thread.send("This is a tournament fixture, so staff still need to settle it (Force Match Result).")
        await lock_thread(thread)
    return True


async def award_win(bot, match_id: str, winner_id: int, by: discord.abc.User) -> bool:
    """Staff walkover: record a 3-0 (single game) or 2-0 (Bo3) win."""
    m = await bot.db.get_match(match_id)
    if not m:
        raise MatchError("That match doesn't exist.")
    hi, lo = config.AWARD_SCORE_BO3 if m["match_type"] == "knockout" else config.AWARD_SCORE_SINGLE
    p1_score, p2_score = (hi, lo) if winner_id == m["player1_id"] else (lo, hi)
    return await finalize_match(
        bot, match_id, approved_by=by, p1_score=p1_score, p2_score=p2_score, forced=True, allow_voided=True,
    )


# ---------------------------------------------------------------------------
# Finalizing a result
# ---------------------------------------------------------------------------
async def finalize_match(bot, match_id: str, *, approved_by: discord.abc.User | None = None,
                         p1_score: int | None = None, p2_score: int | None = None,
                         forced: bool = False, allow_voided: bool = False) -> bool:
    """Apply a result to standings/brackets, log it and close the thread.

    Returns False if the match was already closed. Raises MatchError for unusable scores.
    """
    from utils import tournament  # local import: tournament imports this module

    db = bot.db
    m = await db.get_match(match_id)
    if not m or m["status"] == "completed" or (m["status"] == "voided" and not allow_voided):
        return False

    if p1_score is not None and p2_score is not None:
        error = validate_score(m["match_type"], p1_score, p2_score)
        if error:
            raise MatchError(error)
        await db.update_match(match_id, p1_score=p1_score, p2_score=p2_score, reported_score=f"{p1_score}-{p2_score}")
        m = await db.get_match(match_id)
    if m["p1_score"] is None or m["p2_score"] is None or m["p1_score"] == m["p2_score"]:
        raise MatchError("This match has no valid score to apply.")

    if not await db.claim_completion(match_id, allow_voided=allow_voided):
        return False

    winner_id, loser_id, ws, ls = winner_loser(m)
    match_type = m["match_type"]
    if match_type == "ladder":
        await db.add_ladder_result(winner_id, loser_id, config.LADDER_WIN_POINTS, ws, ls)
    elif match_type == "group":
        await db.add_group_result(winner_id, loser_id, config.GROUP_WIN_POINTS, ws, ls)

    winner, loser = await db.get_player(winner_id), await db.get_player(loser_id)
    how = "forced by staff" if forced else ("approved by staff" if approved_by else "auto-approved")
    await db.add_log(
        match_id,
        f"Completed: {winner['username']} beat {loser['username']} {ws}-{ls} ({match_type}, {how})",
    )

    embed = brand_embed(
        "Match Complete",
        f"Winner: **{winner['username']}** (<@{winner_id}>)\nLoser: **{loser['username']}** (<@{loser_id}>)\n"
        f"Final score: **{ws} - {ls}**" + (" (series)" if match_type == "knockout" else ""),
        color=0x2ECC71,
    )
    embed.add_field(name="Match ID", value=f"`{match_id}`")
    if approved_by:
        embed.add_field(name="Approved by", value=approved_by.mention)
    thread = await get_thread(bot, m["thread_id"])
    if thread:
        try:
            await thread.send(embed=embed)
        except discord.HTTPException:
            pass
        await lock_thread(thread)

    if match_type == "knockout" and m["bracket_round"]:
        await tournament.record_knockout_result(bot, await guild_for(bot, m), m)
    elif match_type == "group":
        await tournament.check_group_stage_complete(bot)
    return True
