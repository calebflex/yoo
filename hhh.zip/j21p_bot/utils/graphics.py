"""Pillow rendering for the J21P graphics: the 1v1 ladder leaderboard and the tournament groups.

Both images are drawn on a background from templates/ (a dark star field). Missing or unreadable
templates are regenerated, so the bot never fails because of a missing file. To use your own art,
drop a PNG with the same name into templates/ (any size, it is scaled to cover the canvas).

Text uses the bundled Inter font (assets/fonts). Names the font cannot show (CJK, Arabic...) fall
back to another installed font, or to "?" - never to empty boxes.

Regenerate the default templates with:  python -m utils.graphics
"""
from __future__ import annotations

import colorsys
import datetime as dt
import hashlib
import io
import logging
import math
from functools import lru_cache
from pathlib import Path

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont, ImageOps

import config

log = logging.getLogger("j21p.graphics")

LEADERBOARD_TEMPLATE = "leaderboard_template.png"
GROUPS_TEMPLATE = "groups_template.png"

# --- palette (taken from the J21P standings template) -------------------------------------
BG = (6, 19, 34)
PANEL = (9, 24, 43)
LINE = (30, 56, 92)
RED = (242, 15, 58)
RED_DARK = (222, 8, 46)
TEXT = (240, 245, 255)
SOFT = (190, 205, 230)
MUTED = (122, 146, 184)
DIM = (86, 108, 144)
GOLD = (255, 196, 61)
SILVER = (203, 213, 230)
BRONZE = (214, 140, 88)
GREEN = (74, 222, 128)
LOSS = (251, 113, 133)
MEDALS = (GOLD, SILVER, BRONZE)

# --- layout -----------------------------------------------------------------------------
W = 1508
TITLE_H = 256
FOOTER_H = 124

LB_BANNER = (24, 262, 1484, 376)
LB_ROWS_TOP = 396
LB_PITCH = 92
LB_ROW_H = 84
LB_MAX_ROWS = 20
LB_MAX_H = LB_ROWS_TOP + LB_MAX_ROWS * LB_PITCH + FOOTER_H
LB_COLS = {"pld": 872, "won": 990, "los": 1108, "gd": 1228, "pts": 1384}

GP_MARGIN = 36
GP_CARD_W = 706
GP_GAP = 24
GP_HEAD = 88
GP_ROW_PITCH = 84
GP_ROW_H = 76
GP_CARD_H = GP_HEAD + 10 + 4 * GP_ROW_PITCH + 10
GP_TOP = 280
GP_MAX_H = GP_TOP + 4 * GP_CARD_H + 3 * GP_GAP + FOOTER_H

LEADERBOARD_SIZE = (W, LB_MAX_H)
GROUPS_SIZE = (W, GP_MAX_H)


# ===========================================================================================
# Fonts
# ===========================================================================================
_FONT_FILES = {
    "medium": "Inter-Medium.otf",
    "bold": "Inter-Bold.otf",
    "extrabold": "Inter-ExtraBold.otf",
}
_SYSTEM_FONTS = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "C:/Windows/Fonts/arialbd.ttf",
]
_FALLBACK_FONTS = [  # tried (in order) for names Inter can't display completely
    "/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/opentype/ipafont-gothic/ipag.ttf",
    "/Library/Fonts/Arial Unicode.ttf",
    "C:/Windows/Fonts/arialuni.ttf",
    "C:/Windows/Fonts/segoeui.ttf",
]


@lru_cache(maxsize=256)
def font(weight: str, size: int):
    size = max(8, int(size))
    candidates: list[str] = []
    if config.FONT_PATH:
        candidates.append(config.FONT_PATH)
    candidates.append(str(config.ASSETS_DIR / "fonts" / _FONT_FILES.get(weight, _FONT_FILES["bold"])))
    candidates += _SYSTEM_FONTS
    for path in candidates:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            continue
    log.warning("No TrueType font found; text will look rough. Check assets/fonts.")
    try:
        return ImageFont.load_default(size=size)
    except TypeError:  # very old Pillow
        return ImageFont.load_default()


@lru_cache(maxsize=64)
def _fallback_font(path: str, size: int):
    try:
        return ImageFont.truetype(path, size)
    except OSError:
        return None


def _glyph_ok(f, ch: str) -> bool:
    """True if the font really has a glyph for `ch` (not its blank/box .notdef)."""
    if ch.isspace() or not hasattr(f, "getmask"):
        return True
    try:
        mask = f.getmask(ch)
        notdef = f.getmask("\uffff")
        return mask.size != notdef.size or bytes(mask) != bytes(notdef)
    except Exception:
        return True


def _covers(f, text: str) -> bool:
    return all(_glyph_ok(f, ch) for ch in text)


def pick_font(weight: str, size: int, text: str):
    """Inter when it can show every character, else the first fallback font that can."""
    primary = font(weight, size)
    if _covers(primary, text):
        return primary, text
    for path in _FALLBACK_FONTS:
        alt = _fallback_font(path, int(size))
        if alt is not None and _covers(alt, text):
            return alt, text
    return primary, "".join(ch if _glyph_ok(primary, ch) else "?" for ch in text)


def fit_text(draw: ImageDraw.ImageDraw, text: str, weight: str, start: int, minimum: int, max_w: float):
    """Largest font between start and minimum that fits max_w; ellipsizes only as a last resort."""
    text = " ".join(str(text).split()) or "-"
    size = start
    while True:
        f, shown = pick_font(weight, size, text)
        if draw.textlength(shown, font=f) <= max_w or size <= minimum:
            break
        size -= 2
    if draw.textlength(shown, font=f) > max_w:
        while len(shown) > 1 and draw.textlength(shown + "...", font=f) > max_w:
            shown = shown[:-1]
        shown = shown.rstrip() + "..."
    return f, shown


def put(draw: ImageDraw.ImageDraw, xy, text: str, f, fill, anchor: str = "lm") -> None:
    try:
        draw.text(xy, text, font=f, fill=fill, anchor=anchor)
    except ValueError:  # bitmap fallback font has no anchor support
        draw.text(xy, text, font=f, fill=fill)


def put_weight(draw, xy, text: str, weight: str, size: int, fill, anchor: str = "lm") -> None:
    f, shown = pick_font(weight, size, text)
    put(draw, xy, shown, f, fill, anchor)


# ===========================================================================================
# Shapes
# ===========================================================================================
def _rrect_mask(w: int, h: int, radii: tuple[int, int, int, int], ss: int = 3) -> Image.Image:
    """Anti-aliased rounded-rectangle mask. radii = (top-left, top-right, bottom-right, bottom-left)."""
    W_, H_ = w * ss, h * ss
    m = Image.new("L", (W_, H_), 0)
    d = ImageDraw.Draw(m)
    d.rectangle([0, 0, W_ - 1, H_ - 1], fill=255)
    tl, tr, br, bl = (min(int(r * ss), W_ // 2, H_ // 2) for r in radii)
    if tl:
        d.rectangle([0, 0, tl - 1, tl - 1], fill=0)
        d.pieslice([0, 0, 2 * tl - 1, 2 * tl - 1], 180, 270, fill=255)
    if tr:
        d.rectangle([W_ - tr, 0, W_ - 1, tr - 1], fill=0)
        d.pieslice([W_ - 2 * tr, 0, W_ - 1, 2 * tr - 1], 270, 360, fill=255)
    if br:
        d.rectangle([W_ - br, H_ - br, W_ - 1, H_ - 1], fill=0)
        d.pieslice([W_ - 2 * br, H_ - 2 * br, W_ - 1, H_ - 1], 0, 90, fill=255)
    if bl:
        d.rectangle([0, H_ - bl, bl - 1, H_ - 1], fill=0)
        d.pieslice([0, H_ - 2 * bl, 2 * bl - 1, H_ - 1], 90, 180, fill=255)
    return m.resize((w, h), Image.LANCZOS)


def rrect(img: Image.Image, box, radii, fill, outline=None, outline_w: int = 2) -> None:
    """Composite a rounded rectangle (RGBA fill, optional outline) onto img."""
    x0, y0, x1, y1 = (int(round(v)) for v in box)
    w, h = x1 - x0, y1 - y0
    if w <= 0 or h <= 0:
        return
    if isinstance(radii, int):
        radii = (radii,) * 4
    mask = _rrect_mask(w, h, radii)
    fill = tuple(fill) + (255,) * (4 - len(fill))
    layer = Image.new("RGBA", (w, h), fill[:3] + (0,))
    layer.putalpha(mask.point(lambda v: v * fill[3] // 255))
    img.alpha_composite(layer, (x0, y0))
    if outline:
        outline = tuple(outline) + (255,) * (4 - len(outline))
        inner = Image.new("L", (w, h), 0)
        inner.paste(_rrect_mask(w - 2 * outline_w, h - 2 * outline_w,
                                tuple(max(0, r - outline_w) for r in radii)), (outline_w, outline_w))
        ring = ImageChops.subtract(mask, inner)
        layer = Image.new("RGBA", (w, h), outline[:3] + (0,))
        layer.putalpha(ring.point(lambda v: v * outline[3] // 255))
        img.alpha_composite(layer, (x0, y0))


# ===========================================================================================
# Avatars and logo
# ===========================================================================================
def _initial_face(name: str, px: int) -> Image.Image:
    digest = hashlib.sha1(name.encode("utf-8", "ignore")).digest()
    hue = digest[0] / 255
    r, g, b = (int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.55, 0.62))
    face = Image.new("RGBA", (px, px), (r, g, b, 255))
    letter = next((c for c in name if c.isalnum()), "?").upper()
    f, shown = pick_font("extrabold", int(px * 0.5), letter)
    put(ImageDraw.Draw(face), (px / 2, px / 2), shown, f, (255, 255, 255, 235), "mm")
    return face


def _face(data: bytes | None, name: str, px: int) -> Image.Image:
    if data:
        try:
            with Image.open(io.BytesIO(data)) as src:
                src.load()
                return ImageOps.fit(src.convert("RGBA"), (px, px), Image.LANCZOS)
        except Exception:
            log.debug("Unreadable avatar for %s, using initial", name)
    return _initial_face(name, px)


def avatar(data: bytes | None, name: str, size: int, ring=None, ring_w: int = 4) -> Image.Image:
    """Round profile picture with an optional coloured ring; falls back to a coloured initial."""
    ss = 4
    total = size + 2 * ring_w
    canvas = Image.new("RGBA", (total * ss, total * ss), (0, 0, 0, 0))
    d = ImageDraw.Draw(canvas)
    if ring:
        d.ellipse([0, 0, total * ss - 1, total * ss - 1], fill=tuple(ring) + (255,))
    inner = size * ss
    mask = Image.new("L", (inner, inner), 0)
    ImageDraw.Draw(mask).ellipse([0, 0, inner - 1, inner - 1], fill=255)
    canvas.paste(_face(data, name, inner), (ring_w * ss, ring_w * ss), mask)
    return canvas.resize((total, total), Image.LANCZOS)


_logo_cache: dict[int, Image.Image | None] = {}


def logo(size: int) -> Image.Image | None:
    if size in _logo_cache:
        return _logo_cache[size]
    result = None
    try:
        with Image.open(config.ASSETS_DIR / "logo.png") as src:
            result = src.convert("RGBA").resize((size, size), Image.LANCZOS)
    except (OSError, ValueError):
        log.warning("assets/logo.png missing; graphics are drawn without the logo")
    _logo_cache[size] = result
    return result


def paste_logo(img: Image.Image, xy: tuple[int, int], size: int) -> None:
    mark = logo(size)
    if mark is None:
        return
    x, y = xy
    glow = Image.new("RGBA", (size * 2, size * 2), (0, 0, 0, 0))
    ImageDraw.Draw(glow).rounded_rectangle(
        [size // 2, size // 2, size * 3 // 2, size * 3 // 2], radius=size // 4, fill=(50, 130, 255, 120)
    )
    glow = glow.filter(ImageFilter.GaussianBlur(size * 0.10))
    img.alpha_composite(glow, (x - size // 2, y - size // 2))
    img.alpha_composite(mark, (x, y))


# ===========================================================================================
# Background template
# ===========================================================================================
def make_background(w: int, h: int, glows: list[tuple[float, float, float, tuple[int, int, int]]],
                    seed: int = 21) -> Image.Image:
    """Dark navy star field with a few soft nebula glows (the look of the J21P standings template)."""
    rng = np.random.default_rng(seed)
    base = Image.new("RGB", (w, h), BG)

    sw, sh = max(1, w // 4), max(1, h // 4)
    yy, xx = np.mgrid[0:sh, 0:sw].astype(np.float32)
    small = np.zeros((sh, sw, 3), np.float32)
    for cx, cy, r, delta in glows:
        g = np.exp(-(((xx - cx / 4) ** 2 + (yy - cy / 4) ** 2) / (2 * (r / 4) ** 2)))
        small += g[..., None] * np.array(delta, np.float32)
    glow = Image.fromarray(np.clip(small, 0, 255).astype(np.uint8)).resize((w, h), Image.BICUBIC)
    base = ImageChops.add(base, glow)

    arr = np.asarray(base, dtype=np.float32).copy()
    tint = np.array([0.72, 0.84, 1.0], np.float32)
    count = int(w * h / 11000)
    for _ in range(count):
        x, y = int(rng.integers(3, w - 3)), int(rng.integers(3, h - 3))
        big = rng.random() < 0.06
        sigma = rng.uniform(1.0, 1.5) if big else rng.uniform(0.45, 0.9)
        peak = rng.uniform(110, 210) if big else min(150.0, 28 + rng.exponential(32))
        rad = 3 if not big else 4
        ys, xs = np.mgrid[-rad:rad + 1, -rad:rad + 1]
        blob = np.exp(-(xs ** 2 + ys ** 2) / (2 * sigma ** 2)) * peak
        arr[y - rad:y + rad + 1, x - rad:x + rad + 1] += blob[..., None] * tint
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))


def _leaderboard_background() -> Image.Image:
    return make_background(*LEADERBOARD_SIZE, glows=[
        (760, 1250, 190, (6, 14, 30)), (260, 620, 280, (3, 8, 16)), (1250, 1900, 240, (4, 9, 20)),
    ], seed=21)


def _groups_background() -> Image.Image:
    return make_background(*GROUPS_SIZE, glows=[
        (380, 820, 230, (5, 12, 26)), (1150, 1620, 280, (5, 12, 26)), (1250, 420, 200, (3, 8, 18)),
    ], seed=77)


_TEMPLATES = {
    LEADERBOARD_TEMPLATE: (LEADERBOARD_SIZE, _leaderboard_background),
    GROUPS_TEMPLATE: (GROUPS_SIZE, _groups_background),
}
_base_cache: dict[str, tuple[float, Image.Image]] = {}


def ensure_templates(force: bool = False) -> None:
    """Create any missing template files. Never raises: read-only disks just log a warning."""
    try:
        config.TEMPLATES_DIR.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        log.warning("Can't create the templates folder (%s); using in-memory backgrounds", exc)
        return
    for name, (_, builder) in _TEMPLATES.items():
        path = config.TEMPLATES_DIR / name
        if force or not path.exists():
            try:
                builder().save(path)
                log.info("Generated template %s", name)
            except OSError as exc:
                log.warning("Couldn't write %s (%s)", path, exc)


def _base(name: str, height: int) -> Image.Image:
    """The template cropped to `height`, as a fresh RGBA image."""
    size, builder = _TEMPLATES[name]
    path = config.TEMPLATES_DIR / name
    try:
        mtime = path.stat().st_mtime
    except OSError:
        mtime = -1.0
    cached = _base_cache.get(name)
    if cached is None or cached[0] != mtime:
        img = None
        if mtime >= 0:
            try:
                with Image.open(path) as src:
                    img = src.convert("RGBA")
            except (OSError, ValueError):
                log.warning("Template %s is unreadable; regenerating in memory", name)
        if img is None:
            img = builder().convert("RGBA")
        if img.size != size:
            img = ImageOps.fit(img, size, Image.LANCZOS)
        cached = (mtime, img)
        _base_cache[name] = cached
    return cached[1].crop((0, 0, size[0], height))


# ===========================================================================================
# Shared pieces
# ===========================================================================================
def _title(img: Image.Image, title: str, subtitle: str) -> None:
    paste_logo(img, (52, 52), 150)
    d = ImageDraw.Draw(img)
    x = 52 + 150 + 38
    f, shown = fit_text(d, title, "extrabold", 92, 56, W - x - 40)
    put(d, (x, 108), shown, f, TEXT)
    f, shown = fit_text(d, subtitle, "medium", 36, 24, W - x - 40)
    put(d, (x, 178), shown, f, MUTED)


def _footer(img: Image.Image) -> None:
    d = ImageDraw.Draw(img)
    h = img.height
    d.line([(W * 0.30, h - FOOTER_H + 26), (W * 0.70, h - FOOTER_H + 26)], fill=LINE, width=2)
    f, shown = fit_text(d, config.CREDITS, "medium", 28, 18, W - 80)
    put(d, (W / 2, h - FOOTER_H + 64), shown, f, MUTED, "mm")
    stamp = dt.datetime.now(dt.timezone.utc).strftime("Updated %d %b %Y  \u2022  %H:%M UTC")
    put(d, (W / 2, h - FOOTER_H + 100), stamp, font("medium", 24), DIM, "mm")


def _to_png(img: Image.Image) -> io.BytesIO:
    buf = io.BytesIO()
    img.convert("RGB").save(buf, "PNG")
    buf.seek(0)
    return buf


def _num(value) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


# ===========================================================================================
# Ladder leaderboard
# ===========================================================================================
def render_leaderboard(players: list[dict], avatars: dict[int, bytes | None] | None = None) -> io.BytesIO:
    """players: rows with username, pts, wins, losses, goals, discord_id (already sorted)."""
    avatars = avatars or {}
    rows = players[:LB_MAX_ROWS]
    n = max(1, len(rows))
    height = LB_ROWS_TOP + n * LB_PITCH + FOOTER_H - 12
    img = _base(LEADERBOARD_TEMPLATE, height)

    _title(img, "J21P 1v1 LADDER", f"OFFICIAL STANDINGS  \u2022  TOP {len(rows) or 20}  \u2022  WIN = +{config.LADDER_WIN_POINTS} PTS")

    x0, y0, x1, y1 = LB_BANNER
    rrect(img, (x0, y1 - 2, x1, height - FOOTER_H + 4), (0, 0, 26, 26), PANEL + (205,), outline=LINE + (150,))
    rrect(img, LB_BANNER, (46, 26, 0, 0), RED + (255,))
    rrect(img, (x0, y1 - 8, x1, y1), (0, 0, 0, 0), RED_DARK + (255,))
    d = ImageDraw.Draw(img)

    mid = (y0 + y1) / 2 + 2
    put_weight(d, (64, mid), "RANK", "extrabold", 34, (255, 255, 255))
    put_weight(d, (268, mid), "PLAYER", "extrabold", 34, (255, 255, 255))
    for key, label in (("pld", "PLD"), ("won", "WON"), ("los", "LOS"), ("gd", "GD"), ("pts", "PTS")):
        put_weight(d, (LB_COLS[key], mid), label, "extrabold", 34, (255, 255, 255), "mm")

    if not rows:
        put_weight(d, (W / 2, LB_ROWS_TOP + 40), "No players yet", "bold", 44, MUTED, "mm")

    for i, p in enumerate(rows):
        top = LB_ROWS_TOP + i * LB_PITCH
        cy = top + LB_ROW_H / 2
        medal = MEDALS[i] if i < 3 else None
        shade = medal + (26,) if medal else ((255, 255, 255, 9) if i % 2 == 0 else (255, 255, 255, 3))
        rrect(img, (40, top, W - 40, top + LB_ROW_H), 20, shade)
        if medal:
            rrect(img, (40, top + 10, 48, top + LB_ROW_H - 10), 4, medal + (255,))

        d = ImageDraw.Draw(img)
        put_weight(d, (112, cy), str(i + 1), "extrabold", 46, medal or SOFT, "mm")

        name = p.get("username") or "?"
        pid = p.get("discord_id")
        face = avatar(avatars.get(pid), name, 64, ring=medal or (44, 76, 120), ring_w=4)
        img.alpha_composite(face, (int(208 - face.width / 2), int(cy - face.height / 2)))

        d = ImageDraw.Draw(img)
        f, shown = fit_text(d, name, "bold", 46, 32, 800 - 268)
        put(d, (268, cy), shown, f, TEXT)

        wins, losses, goals, pts = _num(p.get("wins")), _num(p.get("losses")), _num(p.get("goals")), _num(p.get("pts"))
        stat = font("bold", 44)
        put(d, (LB_COLS["pld"], cy), str(wins + losses), stat, SOFT, "mm")
        put(d, (LB_COLS["won"], cy), str(wins), stat, GREEN if wins else DIM, "mm")
        put(d, (LB_COLS["los"], cy), str(losses), stat, LOSS if losses else DIM, "mm")
        put(d, (LB_COLS["gd"], cy), f"{goals:+d}" if goals else "0", stat, GREEN if goals > 0 else LOSS if goals < 0 else DIM, "mm")
        rrect(img, (LB_COLS["pts"] - 66, top + 12, LB_COLS["pts"] + 66, top + LB_ROW_H - 12), 18,
              RED + (60,), outline=RED + (170,), outline_w=2)
        d = ImageDraw.Draw(img)
        put(d, (LB_COLS["pts"], cy), str(pts), font("extrabold", 48), (255, 255, 255), "mm")

    _footer(img)
    return _to_png(img)


# ===========================================================================================
# Tournament groups
# ===========================================================================================
def render_groups(groups: dict[str, list[dict]], avatars: dict[int, bytes | None] | None = None) -> io.BytesIO:
    """groups maps 'A'..'H' to that group's players, already sorted by standing."""
    avatars = avatars or {}
    letters = [k for k in sorted(groups) if groups[k]][:8]
    card_rows = max(1, math.ceil(len(letters) / 2))
    height = GP_TOP + card_rows * GP_CARD_H + (card_rows - 1) * GP_GAP + FOOTER_H
    img = _base(GROUPS_TEMPLATE, height)
    _title(img, "J21P TOURNAMENT GROUPS", "GROUP STAGE  \u2022  TOP 2 FROM EACH GROUP ADVANCE")

    for idx, letter in enumerate(letters):
        col, row = idx % 2, idx // 2
        x0 = GP_MARGIN + col * (GP_CARD_W + GP_GAP)
        y0 = GP_TOP + row * (GP_CARD_H + GP_GAP)
        x1, y1 = x0 + GP_CARD_W, y0 + GP_CARD_H
        rrect(img, (x0, y0, x1, y1), 26, PANEL + (205,), outline=LINE + (160,))
        rrect(img, (x0, y0, x1, y0 + GP_HEAD), (26, 26, 0, 0), RED + (255,))
        rrect(img, (x0, y0 + GP_HEAD - 6, x1, y0 + GP_HEAD), (0, 0, 0, 0), RED_DARK + (255,))
        d = ImageDraw.Draw(img)
        put_weight(d, (x0 + 32, y0 + GP_HEAD / 2 + 1), f"GROUP {letter}", "extrabold", 46, (255, 255, 255))
        put_weight(d, (x1 - 84, y0 + GP_HEAD / 2 + 1), "PTS", "extrabold", 32, (255, 255, 255), "mm")

        members = groups[letter][:4]
        for k in range(4):
            top = y0 + GP_HEAD + 10 + k * GP_ROW_PITCH
            cy = top + GP_ROW_H / 2
            rrect(img, (x0 + 14, top, x1 - 14, top + GP_ROW_H), 18,
                  (255, 255, 255, 9) if k % 2 == 0 else (255, 255, 255, 3))
            d = ImageDraw.Draw(img)
            if k >= len(members):
                put_weight(d, (x0 + 52, cy), str(k + 1), "bold", 34, DIM, "mm")
                put_weight(d, (x0 + 160, cy), "Open slot", "medium", 30, DIM)
                continue
            p = members[k]
            out = bool(p.get("eliminated"))
            advancing = k < 2 and not out
            if advancing:
                rrect(img, (x0 + 14, top + 10, x0 + 21, top + GP_ROW_H - 10), 3, GREEN + (255,))
            d = ImageDraw.Draw(img)
            put_weight(d, (x0 + 52, cy), str(k + 1), "extrabold", 36, GOLD if advancing else MUTED, "mm")

            name = p.get("username") or "?"
            face = avatar(avatars.get(p.get("discord_id")), name, 52, ring=GREEN if advancing else (44, 76, 120), ring_w=3)
            if out:
                face = Image.blend(face, Image.new("RGBA", face.size, (0, 0, 0, 0)), 0.45)
            img.alpha_composite(face, (int(x0 + 112 - face.width / 2), int(cy - face.height / 2)))

            d = ImageDraw.Draw(img)
            pts_x = x1 - 84
            name_x = x0 + 158
            f, shown = fit_text(d, name, "bold", 38, 26, (pts_x - 62) - name_x)
            put(d, (name_x, cy - 13), shown, f, MUTED if out else TEXT)
            if out:
                width = d.textlength(shown, font=f)
                d.line([(name_x, cy - 13), (name_x + width, cy - 13)], fill=LOSS, width=3)
            gd = _num(p.get("group_gf")) - _num(p.get("group_ga"))
            sub = "Eliminated" if out else f"{_num(p.get('group_w'))}W  {_num(p.get('group_l'))}L  \u2022  GD {gd:+d}"
            put_weight(d, (name_x, cy + 18), sub, "medium", 22, LOSS if out else MUTED)
            rrect(img, (pts_x - 54, top + 12, pts_x + 54, top + GP_ROW_H - 12), 16,
                  RED + (60,), outline=RED + (170,), outline_w=2)
            d = ImageDraw.Draw(img)
            put_weight(d, (pts_x, cy), str(_num(p.get("group_pts"))), "extrabold", 40, (255, 255, 255), "mm")

    _footer(img)
    return _to_png(img)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    ensure_templates(force=True)
    print(f"Templates regenerated in {config.TEMPLATES_DIR}")
