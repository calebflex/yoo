"""Tournament player-list import: parse pasted text, match names to server members, save."""
from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass, field

import config

MENTION_RE = re.compile(r"<@!?(\d{15,22})>")
ID_RE = re.compile(r"^\d{15,22}$")
SPLIT_RE = re.compile(r"\s*[,;\t|]\s*|\s+-\s+")
HEADER_WORDS = {"username", "user", "name", "player", "fc", "ovr", "team", "discord", "id", "#"}
MAX_ENTRIES = 64


@dataclass
class Entry:
    name: str
    ovr: int | None = None
    discord_id: int | None = None
    line: int = 0


@dataclass
class ParseResult:
    entries: list[Entry] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


def clean_name(value: str) -> str:
    value = re.sub(r"[​-‏‪-‮⁠﻿]", "", value)   # zero width + bidi controls
    value = re.sub(r"[\x00-\x1f\x7f]", " ", value)
    value = value.strip().strip("\"'`*_~")
    value = re.sub(r"^\s*\d{1,3}\s*[.)]\s+", "", value)   # "12. name" or "12) name"
    return " ".join(value.split())


def parse(text: str) -> ParseResult:
    """Accepts one player per line. Each line may hold, in any order, separated by comma / tab /
    pipe / semicolon / ' - ':  FC username, Team OVR (100-999), @mention or Discord ID."""
    result = ParseResult()
    seen: set[str] = set()
    lines = [ln for ln in text.replace("\r", "\n").split("\n")]
    for number, raw in enumerate(lines, start=1):
        line = raw.strip()
        if not line or line.startswith(("#", "//")):
            continue
        discord_id = None
        mention = MENTION_RE.search(line)
        if mention:
            discord_id = int(mention.group(1))
            line = (line[:mention.start()] + "," + line[mention.end():]).strip(" ,")
        try:
            parts = [p for p in next(csv.reader([line], skipinitialspace=True))] if "," in line and '"' in line \
                else SPLIT_RE.split(line)
        except csv.Error:
            parts = SPLIT_RE.split(line)
        name, ovr = None, None
        for part in (p.strip() for p in parts):
            if not part:
                continue
            if ID_RE.match(part) and discord_id is None:
                discord_id = int(part)
            elif part.isdigit() and len(part) == 3 and ovr is None and config.OVR_MIN <= int(part) <= config.OVR_MAX:
                ovr = int(part)
            elif name is None:
                name = clean_name(part)
            elif part.isdigit():
                continue
            else:
                name = name  # extra free text is ignored
        if number == 1 and name and name.lower().split()[0] in HEADER_WORDS and ovr is None and discord_id is None:
            continue   # header row of a CSV
        if not name:
            if discord_id is None:
                result.errors.append(f"Line {number}: nothing usable in `{raw.strip()[:40]}`")
                continue
            name = ""
        if name and not config.USERNAME_MIN <= len(name) <= config.USERNAME_MAX:
            result.errors.append(
                f"Line {number}: `{name[:30]}` must be {config.USERNAME_MIN}-{config.USERNAME_MAX} characters")
            continue
        key = name.casefold() if name else f"id:{discord_id}"
        if key in seen:
            result.errors.append(f"Line {number}: `{name or discord_id}` is listed twice, skipped")
            continue
        seen.add(key)
        result.entries.append(Entry(name=name, ovr=ovr, discord_id=discord_id, line=number))
        if len(result.entries) >= MAX_ENTRIES:
            result.errors.append(f"Stopped at {MAX_ENTRIES} entries.")
            break
    return result


@dataclass
class Resolved:
    entry: Entry
    member_id: int | None = None
    member_name: str | None = None
    how: str = ""          # id | exact | display | partial
    note: str = ""


def _names_of(member) -> list[str]:
    out = [getattr(member, "name", None), getattr(member, "display_name", None),
           getattr(member, "global_name", None), getattr(member, "nick", None)]
    return [n.casefold() for n in out if n]


async def resolve(guild, entries: list[Entry]) -> list[Resolved]:
    """Match every entry to a server member by ID, exact name, or a single unambiguous partial match."""
    members = [m for m in getattr(guild, "members", []) if not getattr(m, "bot", False)]
    results: list[Resolved] = []
    claimed: set[int] = set()
    for entry in entries:
        found, how, note = None, "", ""
        if entry.discord_id:
            found = guild.get_member(entry.discord_id)
            if found is None:
                try:
                    found = await guild.fetch_member(entry.discord_id)
                except Exception:
                    found = None
            how = "id"
            if found is None:
                note = "that Discord ID is not in this server"
        if found is None and not entry.discord_id and entry.name:
            needle = entry.name.casefold()
            exact = [m for m in members if needle in _names_of(m)]
            if not exact:
                try:   # needs the Server Members intent; harmless when it is missing
                    queried = await guild.query_members(query=entry.name[:32], limit=10)
                    exact = [m for m in queried if needle in _names_of(m) and not m.bot]
                    members.extend(m for m in queried if m not in members and not m.bot)
                except Exception:
                    pass
            if len(exact) == 1:
                found, how = exact[0], "exact"
            elif len(exact) > 1:
                note = f"{len(exact)} members share that name, add their @mention or ID"
            else:
                partial = [m for m in members if any(needle in n or n in needle for n in _names_of(m) if len(n) >= 3)]
                if len(partial) == 1:
                    found, how = partial[0], "partial"
                elif len(partial) > 1:
                    note = f"{len(partial)} possible members, add their @mention or ID"
                else:
                    note = "no member found"
        if found is not None and found.id in claimed:
            note, found = "that member is already matched to another line", None
        if found is not None:
            claimed.add(found.id)
        results.append(Resolved(
            entry=entry,
            member_id=found.id if found else None,
            member_name=(getattr(found, "display_name", None) or getattr(found, "name", None)) if found else None,
            how=how, note=note,
        ))
    return results


def export_csv(players: list[dict]) -> bytes:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["username", "team_ovr", "discord_id", "group", "stage", "eliminated"])
    for p in players:
        writer.writerow([_csv_safe(p["username"]), p["team_ovr"] or "", p["discord_id"],
                         p["group_name"] or "", p["stage"], int(bool(p["eliminated"]))])
    return buf.getvalue().encode("utf-8-sig")


def _csv_safe(value: str) -> str:
    """Stop spreadsheet formula injection from a hostile username."""
    return "'" + value if value[:1] in "=+-@\t\r" else value
