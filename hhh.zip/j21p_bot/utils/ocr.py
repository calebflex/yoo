"""Screenshot scoreline reader. Supports pytesseract (default) and EasyOCR.

`read_score()` is blocking — call it with `asyncio.to_thread`.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass

from PIL import Image, ImageOps

import config

log = logging.getLogger("j21p.ocr")

# "2-1", "2 - 1", "2–1" ... (dashes only: avoids confusing match clocks like 45:00)
SCORE_RE = re.compile(r"(?<!\d)(\d{1,2})\s*[-–—_]\s*(\d{1,2})(?!\d)")
MAX_GOALS = 25

_easyocr_reader = None


@dataclass
class OCRResult:
    score: tuple[int, int] | None = None
    confidence: float = 0.0       # 0-100
    raw_text: str = ""
    error: str | None = None


def _variants(img: Image.Image):
    """Several preprocessed versions: FC Mobile uses light text on dark backgrounds."""
    gray = ImageOps.autocontrast(ImageOps.grayscale(img))
    w, h = gray.size
    scale = 2 if w < 1600 else 1

    def prep(im: Image.Image) -> Image.Image:
        if scale > 1:
            im = im.resize((im.width * scale, im.height * scale), Image.LANCZOS)
        return im

    crop = gray.crop((int(w * 0.15), int(h * 0.03), int(w * 0.85), int(h * 0.60)))
    yield prep(gray)
    yield prep(ImageOps.invert(gray))
    yield prep(crop)
    yield prep(ImageOps.invert(crop))


def _scan_tokens(tokens: list[tuple[str, float]]) -> list[tuple[int, int, float]]:
    """Find scorelines in a line of (text, confidence) tokens."""
    joined, spans = "", []
    for text, conf in tokens:
        start = len(joined)
        joined += text
        spans.append((start, len(joined), conf))
        joined += " "
    found = []
    for m in SCORE_RE.finditer(joined):
        a, b = int(m.group(1)), int(m.group(2))
        if a > MAX_GOALS or b > MAX_GOALS:
            continue
        confs = [c for s, e, c in spans if s < m.end() and e > m.start()]
        if confs:
            found.append((a, b, sum(confs) / len(confs)))
    return found


def _tesseract(img: Image.Image) -> tuple[list[tuple[int, int, float]], str]:
    import pytesseract
    from pytesseract import Output

    candidates, texts = [], []
    for variant in _variants(img):
        data = pytesseract.image_to_data(variant, config="--psm 6", output_type=Output.DICT)
        lines: dict[tuple, list[tuple[str, float]]] = {}
        for i, text in enumerate(data["text"]):
            text = (text or "").strip()
            if not text:
                continue
            try:
                conf = float(data["conf"][i])
            except (TypeError, ValueError):
                continue
            if conf < 0:
                continue
            key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
            lines.setdefault(key, []).append((text, conf))
        for tokens in lines.values():
            candidates.extend(_scan_tokens(tokens))
            texts.append(" ".join(t for t, _ in tokens))
    return candidates, "\n".join(texts)


def _easyocr(img: Image.Image) -> tuple[list[tuple[int, int, float]], str]:
    global _easyocr_reader
    import easyocr
    import numpy as np

    if _easyocr_reader is None:
        _easyocr_reader = easyocr.Reader(["en"], gpu=False)
    results = _easyocr_reader.readtext(np.array(img.convert("RGB")))
    # Roughly reading order: row first, then left to right.
    results.sort(key=lambda r: (round(r[0][0][1] / 25), r[0][0][0]))
    tokens = [(text.strip(), float(conf) * 100) for _, text, conf in results if text.strip()]
    return _scan_tokens(tokens), " ".join(t for t, _ in tokens)


def read_score(path: str) -> OCRResult:
    """Read the scoreline from a screenshot. Never raises; problems are reported in `.error`."""
    try:
        img = Image.open(path).convert("RGB")
    except Exception as exc:
        return OCRResult(error=f"could not open the screenshot ({exc})")

    try:
        if config.OCR_BACKEND == "easyocr":
            candidates, raw = _easyocr(img)
        else:
            candidates, raw = _tesseract(img)
    except ImportError as exc:
        return OCRResult(error=f"OCR library not installed ({exc.name})")
    except Exception as exc:
        log.warning("OCR failed: %s", exc)
        return OCRResult(error=f"OCR engine unavailable ({str(exc).splitlines()[0][:120]})")

    if not candidates:
        return OCRResult(raw_text=raw)
    a, b, conf = max(candidates, key=lambda c: c[2])
    return OCRResult(score=(a, b), confidence=round(conf, 1), raw_text=raw)
