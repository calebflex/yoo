"""Tournament engine: 8 groups of 4 (32 players) → 16-player Best-of-3 knockout bracket."""
from __future__ import annotations

import asyncio
import itertools
import logging
import math
import random

import discord

import config
from utils import matches
from utils.matches import MatchError, brand_embed

log = logging.getLogger("j21p.tournament")

GROUP_LETTERS = "ABCDEFGH"
ROUNDS = ["R16", "QF", "SF", "F"]
ROUND_SIZES = {"R16": 8, "QF": 4, "SF": 2, "F": 1}
ROUND_LABELS = {"R16": "Round of 16", "QF": "Quarterfinal", "SF": "Semifinal", "F": "Final"}

# Slot i -> R16 match i // 2, side p1 (even) / p2 (odd). Group winners meet runners-up of a
# neighbouring group, and teams from the same group can only meet again in the final.
SEED_PATTERN = [
    ("A", 1), ("B", 2), ("C", 1), ("D", 2), ("E", 1), ("F", 2), ("G", 1), ("H", 2),
    ("B", 1), ("A", 2), ("D", 1), ("C", 2), ("F", 1), ("E", 2), ("H", 1), ("G", 2),
]

_lock = asyncio.Lock()


class TournamentError(MatchError):
    """User-facing tournament problem."""


def next_round(rnd: str) -> str | None:
    i = ROUNDS.index(rnd)
    return ROUNDS[i + 1] if i + 1 < len(ROUNDS) else None


def standing_key(p: dict) -> tuple:
    return (-p["group_pts"], -(p["group_gf"] - p["group_ga"]), -p["group_gf"], -p["group_w"], p["username"].lower())


async def get_state(db) -> str:
    return await db.get_setting("tournament_state", "idle")


async def get_group_standings(db) -> dict[str, list[dict]]:
    groups: dict[str, list[dict]] = {}
    for p in await db.grouped_players():
        groups.setdefault(p["group_name"], []).append(p)
    return {letter: sorted(players, key=standing_key) for letter, players in sorted(groups.items())}


async def get_bracket_data(db) -> tuple[list[dict], dict[int, str], str | None]:
    slots = await db.bracket_all()
    names = {p["discord_id"]: p["username"] for p in await db.list_players()}
    champ_raw = await db.get_setting("champion")
    champion = names.get(int(champ_raw)) if champ_raw and champ_raw.isdigit() else None
    return slots, names, champion


# ---------------------------------------------------------------------------
# Group stage
# ---------------------------------------------------------------------------
async def start_group_stage(bot) -> str:
    """Draw groups, create every fixture and open the match threads.

    Re-running it later only opens threads that failed to open the first time.
    """
    async with _lock:
        db = bot.db
        state = await get_state(db)
        if state == "knockout":
            return await spawn_knockout_threads(bot, summary=True)
        if state == "groups":
            return await _open_missing_threads(bot, "Group stage is already running.")

        players = [p for p in await db.list_players() if not p["eliminated"]]
        if len(players) < 4:
            raise TournamentError(
                f"Need at least 4 registered players to start (there are {len(players)}). The full format is 32."
            )
        note = ""
        if len(players) > 32:
            note = f" Only the first 32 registered players were drawn ({len(players) - 32} left out)."
            players = players[:32]
        random.shuffle(players)

        n_groups = min(8, math.ceil(len(players) / 4))
        groups: dict[str, list[dict]] = {GROUP_LETTERS[i]: [] for i in range(n_groups)}
        for i, p in enumerate(players):
            groups[GROUP_LETTERS[i % n_groups]].append(p)

        for letter, members in groups.items():
            for p in members:
                await db.update_player(
                    p["discord_id"], group_name=letter, stage="group", eliminated=0,
                    group_pts=0, group_w=0, group_l=0, group_gf=0, group_ga=0,
                )
            for a, b in itertools.combinations(members, 2):
                await db.create_match(a["discord_id"], b["discord_id"], "group", round_name=f"Group {letter}")
        await db.set_setting("tournament_state", "groups")
        await db.add_log(None, f"Group stage started: {len(players)} players in {n_groups} groups")

        summary = await _open_missing_threads(bot, f"Group stage started with **{len(players)}** players in **{n_groups}** groups.")
        return summary + note


async def _open_missing_threads(bot, headline: str) -> str:
    pending = await bot.db.matches_without_thread()
    opened, errors = 0, []
    for m in pending:
        try:
            await matches.open_thread(bot, m["id"])
            opened += 1
        except MatchError as exc:
            errors.append(str(exc))
            if "hub channel" in str(exc).lower() or "Create Private Threads" in str(exc):
                break  # setup problem — retrying 47 more times won't help
        except Exception:
            log.exception("Opening thread for match %s failed", m["id"])
            errors.append(f"match #{m['id']}: unexpected error")
        await asyncio.sleep(1.2)  # stay well under Discord's thread-creation rate limits
    text = f"{headline} Opened **{opened}** match thread(s)."
    if errors:
        text += f"\n{len(pending) - opened} could not be opened: {errors[0]}\nRun this option again to retry them."
    return text


async def check_group_stage_complete(bot) -> None:
    db = bot.db
    if await get_state(db) != "groups":
        return
    if await db.count_matches(statuses=("pending", "awaiting_admin", "voided"), match_type="group"):
        return
    if await db.get_setting("group_complete_notified") == "1":
        return
    await db.set_setting("group_complete_notified", "1")
    await matches.announce(
        bot,
        embed=brand_embed(
            "Group Stage Complete",
            "Every group match has been played. Admins can now open **/admin_panel → Start Knockout Bracket**.",
            color=0x2ECC71,
        ),
    )


# ---------------------------------------------------------------------------
# Knockout bracket
# ---------------------------------------------------------------------------
async def start_knockout(bot) -> str:
    async with _lock:
        db = bot.db
        state = await get_state(db)
        if state == "idle":
            raise TournamentError("The group stage hasn't started yet.")
        if state == "knockout":
            raise TournamentError("The knockout bracket already exists.")
        pending = await db.count_matches(statuses=("pending", "awaiting_admin", "voided"), match_type="group")
        if pending:
            raise TournamentError(
                f"{pending} group match(es) are still unfinished. Finish them or use **Force Match Result** first."
            )

        standings = await get_group_standings(db)
        rank_of = {
            p["discord_id"]: (letter, i + 1) for letter, players in standings.items() for i, p in enumerate(players)
        }
        everyone = [p for players in standings.values() for p in players]
        qualified = [p for p in everyone if p["stage"] == "qualified" and not p["eliminated"]]
        if not qualified:  # nobody hand-picked: take the top two of every group
            for players in standings.values():
                for p in players[:2]:
                    if not p["eliminated"]:
                        await db.update_player(p["discord_id"], stage="qualified")
                        qualified.append(p)
        if len(qualified) < 2:
            raise TournamentError("Need at least 2 qualified players to build a bracket.")
        if len(qualified) > 16:
            raise TournamentError(f"{len(qualified)} players are marked qualified, but the bracket holds 16.")

        qualified_ids = {p["discord_id"] for p in qualified}
        for p in everyone:
            if p["discord_id"] not in qualified_ids:
                await db.update_player(p["discord_id"], eliminated=1)

        slots: list[int | None] = [None] * 16
        leftovers = []
        for p in qualified:
            key = rank_of.get(p["discord_id"])
            if key in SEED_PATTERN and slots[SEED_PATTERN.index(key)] is None:
                slots[SEED_PATTERN.index(key)] = p["discord_id"]
            else:
                leftovers.append(p["discord_id"])
        for i in range(16):
            if slots[i] is None and leftovers:
                slots[i] = leftovers.pop(0)

        rows = []
        for rnd in ROUNDS:
            for idx in range(ROUND_SIZES[rnd]):
                row = {"rnd": rnd, "idx": idx, "state": "waiting"}
                if rnd == "R16":
                    row["p1"], row["p2"] = slots[2 * idx], slots[2 * idx + 1]
                    if row["p1"] and row["p2"]:
                        row["state"] = "live"
                rows.append(row)
        await db.bracket_init(rows)
        for pid in slots:
            if pid:
                await db.update_player(pid, stage="R16")

        # Byes: a lone player advances; an empty match is dead. Cascades through the rounds.
        for idx in range(8):
            row = rows[idx]
            if row["state"] == "waiting":
                lone = row["p1"] or row["p2"]
                if lone:
                    await _set_done(bot, "R16", idx, lone)
                else:
                    await _set_dead(bot, "R16", idx)

        await db.set_setting("tournament_state", "knockout")
        await db.add_log(None, f"Knockout started with {len(qualified)} qualified players")
        byes = 16 - len(qualified)
        head = f"Knockout bracket created with **{len(qualified)}** players"
        head += f" ({byes} bye(s))." if byes else "."
        return await spawn_knockout_threads(bot, headline=head, summary=True)


async def _refresh_slot(bot, rnd: str, idx: int) -> None:
    """Recompute a later-round slot from the two matches that feed it."""
    db = bot.db
    slot = await db.bracket_get(rnd, idx)
    if not slot or slot["state"] != "waiting" or rnd == "R16":
        return
    prev = ROUNDS[ROUNDS.index(rnd) - 1]
    a, b = await db.bracket_get(prev, idx * 2), await db.bracket_get(prev, idx * 2 + 1)

    def side(s: dict | None):
        if s is None or s["state"] == "dead":
            return "dead", None
        if s["state"] == "done":
            return "filled", s["winner"]
        return "waiting", None

    (state_a, p1), (state_b, p2) = side(a), side(b)
    await db.bracket_update(rnd, idx, p1=p1, p2=p2)
    if "waiting" in (state_a, state_b):
        return
    if state_a == "filled" and state_b == "filled":
        await db.bracket_update(rnd, idx, state="live")
    elif state_a == "filled" or state_b == "filled":
        await _set_done(bot, rnd, idx, p1 or p2)
    else:
        await _set_dead(bot, rnd, idx)


async def _set_done(bot, rnd: str, idx: int, winner_id: int, loser_id: int | None = None) -> None:
    db = bot.db
    await db.bracket_update(rnd, idx, state="done", winner=winner_id)
    nxt = next_round(rnd)
    if nxt:
        await db.update_player(winner_id, stage=nxt)
    else:
        await db.update_player(winner_id, stage="champion")
        await db.set_setting("champion", str(winner_id))
    if loser_id:
        await db.update_player(loser_id, eliminated=1)
    if nxt:
        await _refresh_slot(bot, nxt, idx // 2)


async def _set_dead(bot, rnd: str, idx: int) -> None:
    await bot.db.bracket_update(rnd, idx, state="dead")
    nxt = next_round(rnd)
    if nxt:
        await _refresh_slot(bot, nxt, idx // 2)


async def spawn_knockout_threads(bot, headline: str = "", summary: bool = False) -> str:
    """Open a match + thread for every live bracket slot that doesn't have one yet."""
    db = bot.db
    opened, errors = 0, []
    for slot in await db.bracket_all():
        if slot["state"] != "live" or slot["match_id"]:
            continue
        label = ROUND_LABELS[slot["rnd"]]
        if ROUND_SIZES[slot["rnd"]] > 1:
            label += f" #{slot['idx'] + 1}"
        try:
            match_id = await matches.create_match(
                bot, slot["p1"], slot["p2"], "knockout",
                round_name=label, bracket_round=slot["rnd"], bracket_idx=slot["idx"],
            )
            await db.bracket_update(slot["rnd"], slot["idx"], match_id=match_id)
            opened += 1
        except MatchError as exc:
            errors.append(str(exc))
        except Exception:
            log.exception("Knockout thread failed for %s %s", slot["rnd"], slot["idx"])
            errors.append("unexpected error")
        await asyncio.sleep(1.0)
    text = f"{headline} Opened **{opened}** knockout thread(s).".strip()
    if errors:
        text += f"\n{len(errors)} could not be opened: {errors[0]}"
    return text


async def record_knockout_result(bot, guild: discord.Guild | None, m: dict) -> None:
    """A Best-of-3 series finished: advance the winner, eliminate the loser, open the next thread."""
    db = bot.db
    slot = await db.bracket_get(m["bracket_round"], m["bracket_idx"])
    if not slot:
        return
    winner_id, loser_id, _, _ = matches.winner_loser(m)
    await db.bracket_update(slot["rnd"], slot["idx"], p1_wins=m["p1_score"], p2_wins=m["p2_score"])
    await _set_done(bot, slot["rnd"], slot["idx"], winner_id, loser_id)
    await spawn_knockout_threads(bot)

    winner = await db.get_player(winner_id)
    if slot["rnd"] == "F":
        await matches.announce(
            bot,
            embed=brand_embed("J21P CHAMPION", f"Congratulations <@{winner_id}> (**{winner['username']}**) — "
                              "you are the J21P tournament champion!", color=0xFFC400),
        )
    else:
        nxt = ROUND_LABELS[next_round(slot["rnd"])]
        await matches.announce(bot, f"<@{winner_id}> (**{winner['username']}**) advances to the **{nxt}**.")


# ---------------------------------------------------------------------------
# Admin helpers
# ---------------------------------------------------------------------------
async def admin_advance(bot, player_id: int) -> str:
    """Set Qualified / Advance Player Stage."""
    db = bot.db
    player = await db.get_player(player_id)
    if not player:
        raise TournamentError("That player isn't registered.")
    state = await get_state(db)

    if state == "knockout":
        for slot in await db.bracket_all():
            if slot["state"] == "live" and player_id in (slot["p1"], slot["p2"]):
                loser = slot["p2"] if slot["p1"] == player_id else slot["p1"]
                if slot["match_id"]:
                    m = await db.get_match(slot["match_id"])
                    if m and m["status"] in ("pending", "awaiting_admin"):
                        await db.update_match(m["id"], status="voided", completed_at=matches.utc_now_sql())
                        thread = await matches.get_thread(bot, m["thread_id"])
                        if thread:
                            await thread.send(f"An admin advanced <@{player_id}>. This match is closed.")
                            await matches.lock_thread(thread)
                await _set_done(bot, slot["rnd"], slot["idx"], player_id, loser)
                await spawn_knockout_threads(bot)
                await db.add_log(slot["match_id"], f"Admin advanced {player['username']} from {slot['rnd']}")
                return f"**{player['username']}** advanced from the {ROUND_LABELS[slot['rnd']]}."
        raise TournamentError(f"**{player['username']}** has no live knockout match to advance from.")

    if state == "groups":
        await db.update_player(player_id, stage="qualified", eliminated=0)
        await db.add_log(None, f"Admin marked {player['username']} as qualified")
        return (
            f"**{player['username']}** is marked **qualified**. If any players are marked, only marked players "
            "enter the bracket; otherwise the top 2 of each group do."
        )
    raise TournamentError("There's no tournament running. Start the group stage first.")


async def fresh_start(bot) -> str:
    db = bot.db
    async with _lock:
        archived = 0
        for m in await db.list_matches():
            if m["match_type"] in ("group", "knockout") and m["thread_id"]:
                thread = await matches.get_thread(bot, m["thread_id"])
                if thread:
                    await matches.lock_thread(thread)
                    archived += 1
        await db.wipe_tournament()
        await db.set_setting("group_complete_notified", None)
        await db.add_log(None, "Fresh Start: tournament data wiped")
    return f"Tournament wiped. Registrations and the ladder were kept. Closed {archived} old thread(s)."
