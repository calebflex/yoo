"""Avatar fetching for the standings images: disk cached, concurrent, never raises."""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Iterable

import config

log = logging.getLogger("j21p.avatars")

_FETCH_TIMEOUT = 6.0
_MAX_CONCURRENT = 8
_MAX_BYTES = 2 * 1024 * 1024


def _cache_path(user_id: int):
    return config.AVATAR_DIR / f"{int(user_id)}.png"


def _read_fresh(user_id: int) -> bytes | None:
    path = _cache_path(user_id)
    try:
        if path.exists() and time.time() - path.stat().st_mtime < config.AVATAR_TTL_HOURS * 3600:
            return path.read_bytes()
    except OSError:
        pass
    return None


def _read_stale(user_id: int) -> bytes | None:
    try:
        path = _cache_path(user_id)
        return path.read_bytes() if path.exists() else None
    except OSError:
        return None


def _write(user_id: int, data: bytes) -> None:
    try:
        config.AVATAR_DIR.mkdir(parents=True, exist_ok=True)
        _cache_path(user_id).write_bytes(data)
    except OSError:
        log.debug("Could not cache avatar for %s", user_id)


async def _fetch_one(bot, user_id: int, guild, sem: asyncio.Semaphore) -> bytes | None:
    cached = await asyncio.to_thread(_read_fresh, user_id)
    if cached:
        return cached
    async with sem:
        try:
            member = guild.get_member(user_id) if guild else None
            user = member or bot.get_user(user_id)
            if user is None:
                user = await asyncio.wait_for(bot.fetch_user(user_id), _FETCH_TIMEOUT)
            asset = getattr(user, "display_avatar", None)
            if asset is None:
                return await asyncio.to_thread(_read_stale, user_id)
            data = await asyncio.wait_for(asset.with_size(128).with_format("png").read(), _FETCH_TIMEOUT)
            if data and len(data) <= _MAX_BYTES:
                await asyncio.to_thread(_write, user_id, data)
                return data
        except Exception as exc:  # network, 404, rate limit: fall back to the old copy or the initial
            log.debug("Avatar fetch failed for %s: %s", user_id, exc)
    return await asyncio.to_thread(_read_stale, user_id)


async def fetch_avatars(bot, user_ids: Iterable[int], guild=None) -> dict[int, bytes | None]:
    """Return {discord_id: png bytes or None}. Missing avatars become None (initial letter fallback)."""
    ids = list(dict.fromkeys(int(i) for i in user_ids if i))
    if not ids:
        return {}
    sem = asyncio.Semaphore(_MAX_CONCURRENT)
    results = await asyncio.gather(*(_fetch_one(bot, i, guild, sem) for i in ids), return_exceptions=True)
    return {i: (r if isinstance(r, (bytes, bytearray)) else None) for i, r in zip(ids, results)}
