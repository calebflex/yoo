"""Small shared UI helpers: safe replies, error-handling views/modals, confirmation prompts."""
from __future__ import annotations

import logging
from typing import Awaitable, Callable

import discord

log = logging.getLogger("j21p.ui")

ERROR_TEXT = "Something went wrong. Please try again, or call an admin if it keeps happening."


async def reply(interaction: discord.Interaction, content: str | None = None, *,
                ephemeral: bool = True, **kwargs) -> None:
    """Respond to an interaction whether or not it has already been acknowledged."""
    try:
        if interaction.response.is_done():
            await interaction.followup.send(content, ephemeral=ephemeral, **kwargs)
        else:
            await interaction.response.send_message(content, ephemeral=ephemeral, **kwargs)
    except discord.HTTPException:
        log.warning("Could not reply to interaction", exc_info=True)


class SafeView(discord.ui.View):
    async def on_error(self, interaction: discord.Interaction, error: Exception,
                       item: discord.ui.Item) -> None:
        log.exception("Error in view %s", type(self).__name__, exc_info=error)
        await reply(interaction, ERROR_TEXT)


class SafeModal(discord.ui.Modal):
    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        log.exception("Error in modal %s", type(self).__name__, exc_info=error)
        await reply(interaction, ERROR_TEXT)


class ConfirmView(SafeView):
    """Ephemeral Confirm / Cancel prompt. `on_confirm` returns the text shown when it finishes."""

    def __init__(self, user_id: int, on_confirm: Callable[[discord.Interaction], Awaitable[str]]):
        super().__init__(timeout=60)
        self.user_id = user_id
        self.on_confirm = on_confirm

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await reply(interaction, "This confirmation isn't yours.")
            return False
        return True

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.stop()
        await interaction.response.edit_message(content="Working on it…", view=None)
        try:
            result = await self.on_confirm(interaction)
        except Exception as exc:  # surfaced to the admin instead of failing silently
            log.exception("Confirmed action failed", exc_info=exc)
            result = f"That failed: {exc}"
        await interaction.edit_original_response(content=result)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.stop()
        await interaction.response.edit_message(content="Cancelled.", view=None)
