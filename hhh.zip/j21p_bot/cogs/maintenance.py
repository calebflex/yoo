"""Background housekeeping: database backups, old file cleanup, stale queue entries."""
from __future__ import annotations

import asyncio
import logging
import time

import discord
from discord.ext import commands, tasks

import config

log = logging.getLogger("j21p.maintenance")


def _delete_old(directory, max_age_days: float, keep: set[str]) -> int:
    removed = 0
    if not directory.exists():
        return 0
    cutoff = time.time() - max_age_days * 86400
    for path in directory.iterdir():
        try:
            if path.is_file() and str(path) not in keep and path.stat().st_mtime < cutoff:
                path.unlink()
                removed += 1
        except OSError:
            continue
    return removed


class MaintenanceCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._last_backup = 0.0

    async def cog_load(self) -> None:
        self.backup_loop.change_interval(hours=max(0.25, config.BACKUP_INTERVAL_HOURS))
        self.backup_loop.start()
        self.cleanup_loop.start()
        self.queue_loop.start()

    async def cog_unload(self) -> None:
        for loop in (self.backup_loop, self.cleanup_loop, self.queue_loop):
            loop.cancel()

    @tasks.loop(hours=6)
    async def backup_loop(self) -> None:
        try:
            path = await self.bot.db.backup(config.BACKUP_KEEP)
            log.info("Database backup written: %s", path.name)
        except Exception:
            log.exception("Database backup failed")

    @tasks.loop(hours=12)
    async def cleanup_loop(self) -> None:
        try:
            referenced = {p for p in await self.bot.db.old_screenshot_paths()}
            # keep screenshots of matches that are still open; age out the rest
            open_paths = {m["screenshot_path"] for m in await self.bot.db.list_matches(statuses=("pending", "awaiting_admin"))
                          if m.get("screenshot_path")}
            removed = await asyncio.to_thread(_delete_old, config.SCREENSHOT_DIR, config.SCREENSHOT_RETENTION_DAYS, open_paths)
            await asyncio.to_thread(_delete_old, config.AVATAR_DIR, 14, set())
            await asyncio.to_thread(_delete_old, config.LOG_DIR, 60, set())
            if removed:
                log.info("Removed %d old screenshot(s) (%d tracked)", removed, len(referenced))
        except Exception:
            log.exception("Cleanup failed")

    @tasks.loop(minutes=5)
    async def queue_loop(self) -> None:
        try:
            async with self.bot.queue_lock:
                stale = await self.bot.db.queue_purge_stale(config.QUEUE_EXPIRY_MINUTES)
            for uid in stale:
                try:
                    user = self.bot.get_user(uid) or await self.bot.fetch_user(uid)
                    await user.send(f"You were removed from the J21P 1v1 queue after {config.QUEUE_EXPIRY_MINUTES} minutes "
                                    "without an opponent. Press Join 1v1 Queue to try again.")
                except (discord.HTTPException, AttributeError):
                    pass
        except Exception:
            log.exception("Queue cleanup failed")

    @backup_loop.before_loop
    @cleanup_loop.before_loop
    @queue_loop.before_loop
    async def _wait(self) -> None:
        await self.bot.wait_until_ready()


async def setup(bot) -> None:
    await bot.add_cog(MaintenanceCog(bot))
