"""/admin_panel: the ephemeral staff dashboard (two dropdown menus).

What each person sees depends on their role tier (see config.py):
  Moderation     pending matches, find a thread, match log, archive a thread
  Event Manager  + start stages, manual threads, eliminate / reinstate / advance
  Executive      + force results, fresh start (wipe)
"""
from __future__ import annotations

import asyncio
import logging
import re

import discord
from discord import app_commands
from discord.ext import commands

import io

from utils import importer, matches, tournament
import config
from utils.checks import (
    is_event_manager, is_event_manager_member, is_executive, is_executive_member,
    is_moderator, is_moderator_member, tier_name,
)
from database.database import UsernameTaken as UsernameTakenError
from utils.matches import MatchError, brand_embed
from utils.ui import ConfirmView, SafeModal, SafeView, reply

log = logging.getLogger("j21p.admin_panel")

TYPE_NAMES = {"ladder": "Ladder", "group": "Group", "knockout": "Bo3"}
NEED_EXEC = "That needs an executive role (Admin and above)."
NEED_EVENT = "That needs the Event Manager role or higher."
NEED_STAFF = "That needs a moderation role."


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
async def _confirm(interaction: discord.Interaction, text: str, action) -> None:
    """Ephemeral Confirm/Cancel prompt; `action(interaction)` returns the result text."""
    await interaction.followup.send(text, view=ConfirmView(interaction.user.id, action), ephemeral=True)


def _match_line(m: dict, names: dict[int, str]) -> str:
    thread = f"<#{m['thread_id']}>" if m["thread_id"] else "no thread"
    where = m["round_name"] or TYPE_NAMES.get(m["match_type"], m["match_type"])
    return (
        f"`{m['id']}` {names.get(m['player1_id'], '?')} vs {names.get(m['player2_id'], '?')} "
        f"| {where} | **{m['status']}** | {thread}"
    )


async def _names(bot) -> dict[int, str]:
    return {p["discord_id"]: p["username"] for p in await bot.db.list_players()}


# ---------------------------------------------------------------------------
# Modals
# ---------------------------------------------------------------------------
class ForceResultModal(SafeModal, title="Force Match / Series Result"):
    match_id = discord.ui.TextInput(
        label="Match ID (8 characters, see View Pending Matches)", placeholder="e.g. 37FE4BD4",
        min_length=8, max_length=8,
    )
    score = discord.ui.TextInput(
        label="Score as PLAYER1-PLAYER2", placeholder="e.g. 2-1  (Bo3: games won, 2-0 or 2-1)", max_length=7,
    )

    def __init__(self, bot):
        super().__init__()
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction) -> None:
        if not is_executive(interaction):
            return await reply(interaction, NEED_EXEC)
        match_id = self.match_id.value.strip().upper()
        try:
            left, right = self.score.value.replace(" ", "").replace("–", "-").split("-")
            p1_score, p2_score = int(left), int(right)
        except ValueError:
            return await reply(interaction, "Use a score like `2-1`.")
        if not re.fullmatch(r"[0-9A-F]{8}", match_id):
            return await reply(interaction, "Match IDs are 8 hex characters, like `37FE4BD4`.")

        m = await self.bot.db.get_match(match_id)
        if not m:
            return await reply(interaction, f"Match `{match_id}` doesn't exist.")
        names = await _names(self.bot)
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            done = await matches.finalize_match(
                self.bot, match_id, approved_by=interaction.user, p1_score=p1_score, p2_score=p2_score,
                forced=True, allow_voided=True,
            )
        except MatchError as exc:
            return await interaction.followup.send(str(exc), ephemeral=True)
        if not done:
            return await interaction.followup.send(f"Match `{match_id}` is already completed.", ephemeral=True)
        await interaction.followup.send(
            f"Forced **{names.get(m['player1_id'], '?')} {p1_score} - {p2_score} {names.get(m['player2_id'], '?')}** "
            f"for match `{match_id}`.",
            ephemeral=True,
        )


# ---------------------------------------------------------------------------
# Sub-views (user pickers)
# ---------------------------------------------------------------------------

class ImportModal(SafeModal, title="Import Tournament Players"):
    data = discord.ui.TextInput(
        label="One player per line", style=discord.TextStyle.paragraph, required=True, max_length=4000,
        placeholder="L10NER, 126\nAymtzs, 130, @Aymtzs\nPhilosopher, 118",
    )

    def __init__(self, bot):
        super().__init__()
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction) -> None:
        if not is_event_manager(interaction):
            return await reply(interaction, NEED_EVENT)
        await interaction.response.defer(ephemeral=True, thinking=True)
        bot = self.bot
        if await tournament.get_state(bot.db) not in ("idle", "registration"):
            return await interaction.followup.send(
                "The tournament has already started, so players can't be imported. Use Fresh Start first.", ephemeral=True)
        parsed = importer.parse(self.data.value)
        if not parsed.entries:
            lines = "\n".join(parsed.errors[:10]) or "No usable lines found."
            return await interaction.followup.send(f"Nothing to import.\n{lines}", ephemeral=True)
        resolved = await importer.resolve(interaction.guild, parsed.entries)
        ready = [r for r in resolved if r.member_id]
        missing = [r for r in resolved if not r.member_id]

        def label(r) -> str:
            name = r.entry.name or r.member_name or str(r.entry.discord_id)
            return discord.utils.escape_markdown(name)

        lines = [f"**Ready to import ({len(ready)})**"]
        for r in ready[:32]:
            ovr = f" ({r.entry.ovr} OVR)" if r.entry.ovr else ""
            who = f" -> {discord.utils.escape_markdown(r.member_name)}" if r.member_name else ""
            lines.append(f"`{r.entry.line:>2}` {label(r)}{ovr}{who}")
        if missing:
            lines.append(f"\n**Not matched, skipped ({len(missing)})**")
            lines += [f"`{r.entry.line:>2}` {label(r)}: {r.note}" for r in missing[:15]]
        if parsed.errors:
            lines.append("\n**Problems**")
            lines += parsed.errors[:10]
        total = await bot.db.count_players()
        if total + len(ready) > config.TOURNAMENT_MAX_PLAYERS:
            lines.append(f"\nNote: {total} are already registered. The draw uses at most {config.TOURNAMENT_MAX_PLAYERS}.")
        if not ready:
            return await interaction.followup.send("\n".join(lines)[:1900], ephemeral=True)

        async def run(i: discord.Interaction) -> str:
            created = updated = clashes = 0
            clash_names: list[str] = []
            for r in ready:
                member = interaction.guild.get_member(r.member_id)
                name = r.entry.name or r.member_name or f"player{r.member_id}"
                try:
                    outcome = await bot.db.upsert_player(r.member_id, name[:config.USERNAME_MAX], r.entry.ovr, source="import")
                except UsernameTakenError:
                    clashes += 1
                    clash_names.append(name)
                    continue
                created += outcome == "created"
                updated += outcome == "updated"
                role = interaction.guild.get_role(config.ROLE_PARTICIPANT)
                if member and role and role not in member.roles:
                    try:
                        await member.add_roles(role, reason="J21P import")
                    except discord.HTTPException:
                        pass
            await bot.db.add_log(None, f"Import by {i.user.id}: {created} new, {updated} updated, {clashes} clashes")
            text = f"Import finished: **{created}** added, **{updated}** updated."
            if clashes:
                text += f" {clashes} skipped because the username belongs to someone else: " + ", ".join(
                    discord.utils.escape_markdown(n) for n in clash_names[:8])
            return text

        view = ConfirmView(interaction.user.id, run)
        view.confirm.label = f"Import {len(ready)} players"
        view.confirm.style = discord.ButtonStyle.success
        await interaction.followup.send("\n".join(lines)[:1900], view=view, ephemeral=True)


class PlayerActionView(SafeView):
    """Pick one user, then run an action on them."""

    PROMPTS = {
        "eliminate": "Who should be **eliminated**?",
        "reinstate": "Who should be **reinstated**?",
        "advance": "Who should be set **qualified / advanced**?",
        "find": "Whose **active match thread** should I find?",
    }
    CHECKS = {
        "eliminate": (is_event_manager, NEED_EVENT),
        "reinstate": (is_event_manager, NEED_EVENT),
        "advance": (is_event_manager, NEED_EVENT),
        "find": (is_moderator, NEED_STAFF),
    }

    def __init__(self, bot, action: str):
        super().__init__(timeout=120)
        self.bot, self.action = bot, action
        picker = discord.ui.UserSelect(placeholder="Select a player...", min_values=1, max_values=1)
        picker.callback = self.picked
        self.picker = picker
        self.add_item(picker)

    async def picked(self, interaction: discord.Interaction) -> None:
        allowed, message = self.CHECKS[self.action]
        if not allowed(interaction):
            return await reply(interaction, message)
        user = self.picker.values[0]
        db = self.bot.db
        player = await db.get_player(user.id)
        if not player:
            return await interaction.response.edit_message(content=f"{user.mention} isn't registered.", view=None)
        await interaction.response.defer()

        try:
            if self.action == "eliminate":
                await db.update_player(user.id, eliminated=1)
                await db.add_log(None, f"{interaction.user} eliminated {player['username']}")
                text = f"**{player['username']}** is now eliminated."
            elif self.action == "reinstate":
                await db.update_player(user.id, eliminated=0)
                await db.add_log(None, f"{interaction.user} reinstated {player['username']}")
                text = f"**{player['username']}** has been reinstated."
            elif self.action == "advance":
                text = await tournament.admin_advance(self.bot, user.id)
            else:
                active = await db.player_active_matches(user.id)
                if not active:
                    text = f"**{player['username']}** has no active match."
                else:
                    names = await _names(self.bot)
                    text = f"Active matches for **{player['username']}**:\n" + "\n".join(_match_line(m, names) for m in active)
        except MatchError as exc:
            text = str(exc)
        await interaction.edit_original_response(content=text, view=None)


class ManualThreadView(SafeView):
    """Pick two players and a match type, then create a thread."""

    def __init__(self, bot):
        super().__init__(timeout=180)
        self.bot = bot
        self.users: list[discord.abc.User] = []
        self.match_type = "ladder"

        picker = discord.ui.UserSelect(placeholder="Select exactly 2 players...", min_values=2, max_values=2)
        picker.callback = self.on_users
        self.add_item(picker)
        self.picker = picker

        kind = discord.ui.Select(
            placeholder="Match type",
            options=[
                discord.SelectOption(label="Ladder match (single game)", value="ladder", default=True),
                discord.SelectOption(label="Group-stage match (same group)", value="group"),
                discord.SelectOption(label="Knockout series (Best of 3, not linked to bracket)", value="knockout"),
            ],
        )
        kind.callback = self.on_kind
        self.kind = kind
        self.add_item(kind)

    async def on_users(self, interaction: discord.Interaction) -> None:
        self.users = list(self.picker.values)
        await interaction.response.defer()

    async def on_kind(self, interaction: discord.Interaction) -> None:
        self.match_type = self.kind.values[0]
        for option in self.kind.options:
            option.default = option.value == self.match_type
        await interaction.response.edit_message(view=self)

    @discord.ui.button(label="Create Thread", style=discord.ButtonStyle.success, row=2)
    async def create(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if not is_event_manager(interaction):
            return await reply(interaction, NEED_EVENT)
        if len(self.users) != 2 or self.users[0].id == self.users[1].id:
            return await reply(interaction, "Select two different players first.")
        if any(u.bot for u in self.users):
            return await reply(interaction, "Bots can't play matches.")

        db = self.bot.db
        a, b = (await db.get_player(u.id) for u in self.users)
        if not a or not b:
            missing = [u.mention for u, p in zip(self.users, (a, b)) if not p]
            return await reply(interaction, f"Not registered: {', '.join(missing)}")

        round_name = None
        if self.match_type == "group":
            if not a["group_name"] or a["group_name"] != b["group_name"]:
                return await reply(interaction, "Group matches need two players in the **same group**.")
            round_name = f"Group {a['group_name']}"
        elif self.match_type == "knockout":
            round_name = "Manual series"

        await interaction.response.edit_message(content="Creating the match thread...", view=None)
        try:
            match_id = await matches.create_match(self.bot, a["discord_id"], b["discord_id"], self.match_type, round_name=round_name)
        except MatchError as exc:
            return await interaction.edit_original_response(content=str(exc))
        thread_id = (await db.get_match(match_id))["thread_id"]
        await db.add_log(match_id, f"Manual thread created by {interaction.user}")
        await interaction.edit_original_response(content=f"Match `{match_id}` created: <#{thread_id}>")


# ---------------------------------------------------------------------------
# The two dropdowns (options depend on the person's tier)
# ---------------------------------------------------------------------------
def tournament_options(member) -> list[discord.SelectOption]:
    options: list[discord.SelectOption] = []
    if is_event_manager_member(member):
        options += [
            discord.SelectOption(label="Start Group Stage / Auto-Create Threads", value="start_groups",
                                 description="Draw groups and open every match thread (re-run to retry failures)"),
            discord.SelectOption(label="Start Knockout Bracket", value="start_knockout",
                                 description="Build the Best-of-3 bracket from the group results"),
            discord.SelectOption(label="Import Player List", value="import",
                                 description="Paste usernames (optionally OVR and @mention)"),
            discord.SelectOption(label="Export Player List (CSV)", value="export",
                                 description="Download all registered players"),
            discord.SelectOption(label="Create Manual Match Thread", value="manual_thread",
                                 description="Pick two players and open a thread"),
            discord.SelectOption(label="Eliminate Player", value="eliminate"),
            discord.SelectOption(label="Reinstate Player", value="reinstate"),
            discord.SelectOption(label="Set Qualified / Advance Player Stage", value="advance",
                                 description="Mark qualified in groups, or advance a player in the bracket"),
        ]
    if is_executive_member(member):
        options.append(discord.SelectOption(
            label="Fresh Start (wipe tournament data)", value="fresh_start",
            description="Needs confirmation. Keeps registrations and the ladder",
        ))
    return options


def match_options(member) -> list[discord.SelectOption]:
    options: list[discord.SelectOption] = []
    if is_executive_member(member):
        options.append(discord.SelectOption(
            label="Force Match / Bo3 Series Result", value="force", description="Bypasses the players and OCR",
        ))
    if is_moderator_member(member):
        options += [
            discord.SelectOption(label="View Pending Matches", value="pending"),
            discord.SelectOption(label="Find Player's Active Match Thread", value="find"),
            discord.SelectOption(label="View Match Log", value="log"),
            discord.SelectOption(label="Archive / Close Current Thread", value="archive",
                                 description="Run /admin_panel inside the thread you want to close"),
        ]
    return options


class TournamentSelect(discord.ui.Select):
    def __init__(self, bot, options: list[discord.SelectOption]):
        super().__init__(placeholder="Tournament Management...", options=options)
        self.bot = bot

    async def callback(self, interaction: discord.Interaction) -> None:
        choice, bot = self.values[0], self.bot
        if choice == "fresh_start":
            if not is_executive(interaction):
                return await reply(interaction, NEED_EXEC)
        elif not is_event_manager(interaction):
            return await reply(interaction, NEED_EVENT)
        if choice == "import":
            await interaction.response.send_modal(ImportModal(bot))
            try:
                await interaction.message.edit(view=AdminPanelView(bot, interaction.user))
            except discord.HTTPException:
                pass
            return
        # Re-send the panel so the dropdown resets and can be used again.
        await interaction.response.edit_message(view=AdminPanelView(bot, interaction.user))

        if choice == "start_groups":
            async def run(i: discord.Interaction) -> str:
                return await tournament.start_group_stage(bot)
            await _confirm(interaction, "Draw the groups and create **every group match thread** (up to 48, "
                                        "each one is a private thread with both players). If the stage already "
                                        "started, this only retries missing threads.", run)
        elif choice == "start_knockout":
            async def run(i: discord.Interaction) -> str:
                return await tournament.start_knockout(bot)
            await _confirm(interaction, "Build the knockout bracket from the group standings and open the first threads?", run)
        elif choice == "export":
            players = await bot.db.list_players()
            data = await asyncio.to_thread(importer.export_csv, players)
            await interaction.followup.send(f"{len(players)} registered players.",
                                            file=discord.File(io.BytesIO(data), filename="j21p_players.csv"), ephemeral=True)
        elif choice == "manual_thread":
            await interaction.followup.send("Pick two players and a match type:", view=ManualThreadView(bot), ephemeral=True)
        elif choice in ("eliminate", "reinstate", "advance"):
            await interaction.followup.send(PlayerActionView.PROMPTS[choice], view=PlayerActionView(bot, choice), ephemeral=True)
        elif choice == "fresh_start":
            async def run(i: discord.Interaction) -> str:
                return await tournament.fresh_start(bot)
            await _confirm(interaction, "**Wipe all tournament data** (groups, bracket, group/knockout matches)? "
                                        "Registrations and ladder stats are kept. This can't be undone.", run)


class MatchSelect(discord.ui.Select):
    def __init__(self, bot, options: list[discord.SelectOption]):
        super().__init__(placeholder="Match & Dispute Resolution...", options=options)
        self.bot = bot

    async def callback(self, interaction: discord.Interaction) -> None:
        choice, bot, db = self.values[0], self.bot, self.bot.db

        if choice == "force":
            if not is_executive(interaction):
                return await reply(interaction, NEED_EXEC)
            return await interaction.response.send_modal(ForceResultModal(bot))
        if not is_moderator(interaction):
            return await reply(interaction, NEED_STAFF)

        await interaction.response.edit_message(view=AdminPanelView(bot, interaction.user))

        if choice == "pending":
            pending = await db.list_matches(statuses=("pending", "awaiting_admin", "voided"))
            if not pending:
                return await interaction.followup.send("No pending matches.", ephemeral=True)
            names = await _names(bot)
            lines = [_match_line(m, names) for m in pending[:20]]
            more = f"\n...and {len(pending) - 20} more." if len(pending) > 20 else ""
            await interaction.followup.send(embed=brand_embed(f"Pending Matches ({len(pending)})", "\n".join(lines) + more), ephemeral=True)

        elif choice == "find":
            await interaction.followup.send(PlayerActionView.PROMPTS["find"], view=PlayerActionView(bot, "find"), ephemeral=True)

        elif choice == "log":
            logs = await db.recent_logs(15)
            if not logs:
                return await interaction.followup.send("The match log is empty.", ephemeral=True)
            body = "\n".join(
                f"`{row['created_at'][5:16]}` {('`' + row['match_id'] + '` ') if row['match_id'] else ''}{row['text']}"
                for row in logs
            )
            await interaction.followup.send(embed=brand_embed("Match Log (latest 15)", body[:4000]), ephemeral=True)

        elif choice == "archive":
            thread = interaction.channel
            if not isinstance(thread, discord.Thread):
                return await interaction.followup.send(
                    "Open `/admin_panel` **inside the match thread** you want to close, then pick this option.", ephemeral=True,
                )
            m = await db.get_match_by_thread(thread.id)
            note = "" if not m or m["status"] in matches.CLOSED_STATUSES else (
                f"\nMatch `{m['id']}` is still **{m['status']}**. It stays open in the database "
                "(void it or settle it first if it should end)."
            )
            await interaction.followup.send(f"Closing this thread.{note}", ephemeral=True)
            await thread.send(f"{interaction.user.mention} closed this thread.")
            await matches.lock_thread(thread)


class AdminPanelView(SafeView):
    def __init__(self, bot, member):
        super().__init__(timeout=600)
        self.bot = bot
        t_options, m_options = tournament_options(member), match_options(member)
        if t_options:
            self.add_item(TournamentSelect(bot, t_options))
        if m_options:
            self.add_item(MatchSelect(bot, m_options))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not is_moderator(interaction):
            await reply(interaction, NEED_STAFF)
            return False
        return True


def panel_embed(state: str, member) -> discord.Embed:
    labels = {"idle": "Not started", "groups": "Group stage", "knockout": "Knockout bracket"}
    embed = brand_embed("J21P Admin Panel", "Use the dropdowns below. Only you can see this panel.")
    embed.add_field(name="Tournament status", value=labels.get(state, state), inline=True)
    embed.add_field(name="Your access", value=tier_name(member), inline=True)
    return embed


class AdminPanelCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="admin_panel", description="Open the J21P staff dashboard (moderators and above).")
    @app_commands.guild_only()
    async def admin_panel(self, interaction: discord.Interaction) -> None:
        if not is_moderator(interaction):
            return await reply(interaction, "This panel is for staff only.")
        state = await tournament.get_state(self.bot.db)
        await interaction.response.send_message(
            embed=panel_embed(state, interaction.user),
            view=AdminPanelView(self.bot, interaction.user),
            ephemeral=True,
        )


async def setup(bot) -> None:
    await bot.add_cog(AdminPanelCog(bot))
