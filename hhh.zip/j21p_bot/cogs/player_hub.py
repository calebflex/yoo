"""/player_hub — the persistent player panel: register, queue, and graphic dropdown."""
from __future__ import annotations

import asyncio
import logging

import discord
from discord import app_commands
from discord.ext import commands

import config
from database.database import UsernameTaken
from utils import avatars as avatar_utils
from utils import graphics, matches, tournament
from utils.checks import is_executive
from utils.matches import MatchError, brand_embed
from utils.ui import SafeModal, SafeView, reply

log = logging.getLogger("j21p.player_hub")


class RegisterModal(SafeModal, title="J21P Registration"):
    username = discord.ui.TextInput(
        label="FC Mobile username", placeholder="e.g. L10NER", min_length=2, max_length=24,
    )
    ovr = discord.ui.TextInput(
        label="Team OVR", placeholder="3-digit number, e.g. 126", min_length=3, max_length=3,
    )

    def __init__(self, bot, existing: dict | None = None):
        super().__init__()
        self.bot = bot
        if existing:
            self.username.default = existing["username"]
            if existing["team_ovr"]:
                self.ovr.default = str(existing["team_ovr"])

    async def on_submit(self, interaction: discord.Interaction) -> None:
        name = " ".join(self.username.value.split())
        if len(name) < 2:
            return await reply(interaction, "Please enter a valid username.")
        raw = self.ovr.value.strip()
        if not raw.isdigit() or not config.OVR_MIN <= int(raw) <= config.OVR_MAX:
            return await reply(interaction, "Team OVR must be a 3-digit number, e.g. `126`.")

        previous = await self.bot.db.get_player(interaction.user.id)
        try:
            await self.bot.db.upsert_player(interaction.user.id, name, int(raw))
        except UsernameTaken:
            return await reply(interaction, f"The username **{discord.utils.escape_markdown(name)}** is already registered to another player. Use your own FC Mobile name, or ask staff for help.")
        note = await give_participant_role(interaction)
        verb = "Updated" if previous else "Registered"
        await reply(
            interaction,
            f"{verb}: **{discord.utils.escape_markdown(name)}** ({int(raw)} OVR).{note}"
            + ("" if previous else " Hit **Join 1v1 Queue** to find a match."),
        )


async def give_participant_role(interaction: discord.Interaction) -> str:
    """Assign (or verify) the Tournament Participants role. Returns an extra note for the reply."""
    member = interaction.user
    guild = interaction.guild
    if guild is None or not isinstance(member, discord.Member):
        return ""
    role = guild.get_role(config.ROLE_PARTICIPANT)
    if role is None:
        log.warning("Participant role %s not found in guild %s", config.ROLE_PARTICIPANT, guild.id)
        return ""
    if role in member.roles:
        return ""
    try:
        await member.add_roles(role, reason="J21P registration")
    except discord.Forbidden:
        log.warning("Missing permission to give %s the participant role (check role hierarchy)", member)
        return " I couldn't give you the participant role, tell a staff member."
    except discord.HTTPException:
        log.warning("Failed to give participant role to %s", member, exc_info=True)
        return ""
    return f" You now have the {role.name} role."


class HubSelect(discord.ui.Select):
    def __init__(self, bot):
        super().__init__(
            custom_id="j21p:hub_select",
            placeholder="View the ladder leaderboard or tournament groups",
            options=[
                discord.SelectOption(label="Ladder Leaderboard", value="ladder",
                                     description="Top J21P 1v1 ladder standings"),
                discord.SelectOption(label="Tournament Groups", value="groups",
                                     description="Group stage standings, Groups A to H"),
            ],
        )
        self.bot = bot

    async def callback(self, interaction: discord.Interaction) -> None:
        db, choice = self.bot.db, self.values[0]
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            if choice == "ladder":
                players = await db.ladder_top(config.LADDER_LEADERBOARD_SIZE)
                if not players:
                    return await interaction.followup.send(
                        "No ladder games have been played yet. Register and join the queue to get on the board.",
                        ephemeral=True)
                faces = await avatar_utils.fetch_avatars(self.bot, [p["discord_id"] for p in players], interaction.guild)
                buf = await asyncio.to_thread(graphics.render_leaderboard, players, faces)
                filename, title = "j21p_leaderboard.png", "J21P 1v1 Ladder Leaderboard"
            else:
                groups = await tournament.get_group_standings(db)
                if not groups:
                    return await interaction.followup.send(
                        "The groups have not been drawn yet. Check back once the tournament starts.", ephemeral=True)
                ids = [p["discord_id"] for members in groups.values() for p in members]
                faces = await avatar_utils.fetch_avatars(self.bot, ids, interaction.guild)
                buf = await asyncio.to_thread(graphics.render_groups, groups, faces)
                filename, title = "j21p_groups.png", "J21P Tournament Groups"

            embed = brand_embed(title)
            embed.set_image(url=f"attachment://{filename}")
            await interaction.followup.send(embed=embed, file=discord.File(buf, filename=filename), ephemeral=True)
        except Exception:
            log.exception("Failed to render %s", choice)
            await interaction.followup.send("I couldn't draw that image right now. Please try again in a moment.", ephemeral=True)
        finally:
            # Put the dropdown back to its un-selected look so the same option can be picked again.
            try:
                await interaction.message.edit(view=HubView(self.bot))
            except discord.HTTPException:
                pass


class HubView(SafeView):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot
        self.add_item(HubSelect(bot))

    @discord.ui.button(label="Register", style=discord.ButtonStyle.primary,
                       custom_id="j21p:register", row=0)
    async def register(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        existing = await self.bot.db.get_player(interaction.user.id)
        await interaction.response.send_modal(RegisterModal(self.bot, existing))

    @discord.ui.button(label="Join 1v1 Queue", style=discord.ButtonStyle.success,
                       custom_id="j21p:queue_join", row=0)
    async def join_queue(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        bot, db, uid = self.bot, self.bot.db, interaction.user.id
        await interaction.response.defer(ephemeral=True, thinking=True)

        async with bot.queue_lock:
            if not await db.get_player(uid):
                return await interaction.followup.send("Please **Register** first so I know your FC Mobile username.", ephemeral=True)
            if uid in await db.queue_list():
                return await interaction.followup.send("You're already in the queue — hang tight!", ephemeral=True)
            active = await db.player_active_matches(uid, "ladder")
            if active:
                ref = f"<#{active[0]['thread_id']}>" if active[0]["thread_id"] else f"match `{active[0]['id']}`"
                return await interaction.followup.send(f"You already have an unfinished ladder match: {ref}", ephemeral=True)

            await db.queue_add(uid)
            my_thread = None
            try:
                while True:
                    waiting = await db.queue_list()
                    if len(waiting) < 2:
                        break
                    a, b = waiting[0], waiting[1]
                    match_id = await matches.create_match(bot, a, b, "ladder")
                    await db.queue_remove(a)
                    await db.queue_remove(b)
                    if uid in (a, b):
                        my_thread = (await db.get_match(match_id))["thread_id"]
            except MatchError as exc:
                if my_thread is None:
                    await db.queue_remove(uid)
                return await interaction.followup.send(f"I couldn't open a match thread: {exc}", ephemeral=True)

            if my_thread:
                return await interaction.followup.send(f"**Match found!** Head to <#{my_thread}> — good luck!", ephemeral=True)
            position = (await db.queue_list()).index(uid) + 1
            await interaction.followup.send(
                f"You're in the queue (position **{position}**). I'll open a private thread and ping you as soon as an opponent joins.",
                ephemeral=True,
            )

    @discord.ui.button(label="Leave Queue", style=discord.ButtonStyle.secondary,
                       custom_id="j21p:queue_leave", row=0)
    async def leave_queue(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        async with self.bot.queue_lock:
            removed = await self.bot.db.queue_remove(interaction.user.id)
        await reply(interaction, "You left the queue." if removed else "You weren't in the queue.")


def hub_embed() -> discord.Embed:
    embed = brand_embed(
        "J21P 1v1 & Tournament Hub",
        "Everything runs from this panel — **no commands to memorise**.",
    )
    embed.add_field(
        name="1v1 Ladder",
        value=(
            "1. Press **Register** and enter your FC Mobile username and Team OVR.\n"
            "2. Press **Join 1v1 Queue** — when an opponent joins, I open a private match thread for you both.\n"
            "3. Inside the thread: send the match code, play, report the score and confirm. Done!"
        ),
        inline=False,
    )
    embed.add_field(
        name="Tournament",
        value=(
            "32 players, 8 groups of 4, then the top 2 of each group reach the **Best-of-3 knockout**. "
            "Your coach opens your match threads automatically."
        ),
        inline=False,
    )
    embed.add_field(name="Standings", value="Use the dropdown below to see the **Ladder Leaderboard** or the **Tournament Groups**.", inline=False)
    return embed


class PlayerHubCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="player_hub", description="Post the J21P 1v1 & Tournament Hub panel in this channel (executives only).")
    @app_commands.guild_only()
    async def player_hub(self, interaction: discord.Interaction) -> None:
        if not is_executive(interaction):
            return await reply(interaction, "Only executives (Admin and above) can post the hub.")
        channel = interaction.channel
        if not isinstance(channel, discord.TextChannel):
            return await reply(interaction, "Please run this in a normal text channel (not a thread or forum).")

        await interaction.response.defer(ephemeral=True)
        try:
            message = await channel.send(embed=hub_embed(), view=HubView(self.bot))
        except discord.Forbidden:
            return await interaction.followup.send("I can't send messages in this channel.", ephemeral=True)
        await self.bot.db.set_setting("hub_channel_id", str(channel.id))
        await self.bot.db.set_setting("hub_message_id", str(message.id))
        await interaction.followup.send(
            f"Hub posted. Match threads will be created in {channel.mention}.\n"
            "Make sure I have **Create Private Threads**, **Send Messages in Threads** and **Manage Threads** here.",
            ephemeral=True,
        )


async def setup(bot) -> None:
    await bot.add_cog(PlayerHubCog(bot))
