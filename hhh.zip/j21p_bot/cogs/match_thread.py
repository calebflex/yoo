"""Everything that happens inside a private match thread: buttons, modals, room-code detection,
score confirmation, moderator requests and the match timers."""
from __future__ import annotations

import asyncio
import logging
import re
import time

import discord
from discord.ext import commands, tasks

import config
from utils import matches
from utils.checks import is_moderator
from utils.matches import MatchError, MATCH_ID_RE, opponent_of
from utils.ui import SafeModal, SafeView, reply

log = logging.getLogger("j21p.match_thread")

IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".webp", ".gif")
SCREENSHOT_WAIT_SECONDS = 180
NO_STAFF = "Only Trial Moderators and above can use these buttons."


def _is_image(attachment: discord.Attachment) -> bool:
    if attachment.content_type and attachment.content_type.startswith("image/"):
        return True
    return attachment.filename.lower().endswith(IMAGE_EXTENSIONS)


def _disabled_copy(view_cls, bot) -> discord.ui.View:
    view = view_cls(bot)
    for child in view.children:
        child.disabled = True
    return view


def _disabled_from_message(message: discord.Message) -> discord.ui.View:
    """Same buttons (labels included) as the message has now, all greyed out."""
    view = discord.ui.View.from_message(message, timeout=None)
    for child in view.children:
        child.disabled = True
    return view


async def _open_match(bot, interaction: discord.Interaction) -> dict | None:
    """Find the match for this thread and make sure the clicker may act on it."""
    m = await bot.db.get_match_by_thread(interaction.channel_id)
    if not m:
        await reply(interaction, "No match is linked to this thread.")
        return None
    if m["status"] in matches.CLOSED_STATUSES:
        await reply(interaction, "This match is already closed.")
        return None
    if interaction.user.id not in (m["player1_id"], m["player2_id"]) and not is_moderator(interaction):
        await reply(interaction, "Only the two players in this match (or staff) can use these buttons.")
        return None
    return m


# ===========================================================================
# Modals
# ===========================================================================
class SendCodeModal(SafeModal, title="Send Match Code"):
    code = discord.ui.TextInput(
        label="6-digit FC Mobile room code", placeholder="123456", min_length=6, max_length=6,
    )

    def __init__(self, bot, match_id: str):
        super().__init__()
        self.bot, self.match_id = bot, match_id

    async def on_submit(self, interaction: discord.Interaction) -> None:
        value = self.code.value.strip()
        if not matches.CODE_RE.match(value):
            return await reply(interaction, "The code must be exactly **6 digits**.")
        m = await self.bot.db.get_match(self.match_id)
        if not m or m["status"] in matches.CLOSED_STATUSES:
            return await reply(interaction, "This match is already closed.")
        if interaction.user.id not in (m["player1_id"], m["player2_id"]):
            return await reply(interaction, "Only the players can send the match code.")
        first = await matches.record_code(self.bot, m, value)
        opponent = opponent_of(m, interaction.user.id)
        await interaction.response.send_message(
            f"{interaction.user.mention} sent the room code:\n# `{value}`\n"
            + matches.code_recorded_text(m, first, opponent),
        )


class ReportScoreModal(SafeModal, title="Report Score"):
    my_score = discord.ui.TextInput(label="Your score", placeholder="e.g. 3", min_length=1, max_length=2)
    opp_score = discord.ui.TextInput(label="Opponent's score", placeholder="e.g. 1", min_length=1, max_length=2)

    def __init__(self, bot, match: dict):
        super().__init__()
        self.bot, self.match_id, self.match_type = bot, match["id"], match["match_type"]
        if self.match_type == "knockout":
            self.title = "Report Series Score (Best of 3)"
            self.my_score.label = "Games YOU won"
            self.opp_score.label = "Games your OPPONENT won"
            self.my_score.placeholder = "2"
            self.opp_score.placeholder = "0 or 1"

    async def on_submit(self, interaction: discord.Interaction) -> None:
        bot, db = self.bot, self.bot.db
        try:
            mine, theirs = int(self.my_score.value.strip()), int(self.opp_score.value.strip())
        except ValueError:
            return await reply(interaction, "Scores must be whole numbers.")
        error = matches.validate_score(self.match_type, mine, theirs)
        if error:
            return await reply(interaction, error)

        m = await db.get_match(self.match_id)
        if not m or m["status"] != "pending":
            return await reply(interaction, "This match can't take a new report right now.")
        if m["reported_score"]:
            return await reply(interaction, "A score is already waiting for confirmation.")
        if self.match_id in bot.pending_reports:
            return await reply(interaction, "A report is already in progress for this match.")
        if interaction.user.id not in (m["player1_id"], m["player2_id"]):
            return await reply(interaction, "Only the players can report the score.")

        reporter = interaction.user.id
        opponent = opponent_of(m, reporter)
        p1_score, p2_score = (mine, theirs) if reporter == m["player1_id"] else (theirs, mine)
        bot.pending_reports.add(self.match_id)
        try:
            await interaction.response.send_message(
                f"Score noted: **{mine} - {theirs}**.\n"
                f"Now **upload your end-of-match screenshot in this thread** within "
                f"{SCREENSHOT_WAIT_SECONDS // 60} minutes (attach the image and send it).",
                ephemeral=True,
            )

            def check(msg: discord.Message) -> bool:
                return (
                    msg.author.id == reporter
                    and msg.channel.id == interaction.channel_id
                    and any(_is_image(a) for a in msg.attachments)
                )

            try:
                message = await bot.wait_for("message", check=check, timeout=SCREENSHOT_WAIT_SECONDS)
            except asyncio.TimeoutError:
                return await interaction.followup.send(
                    "No screenshot received in time, so the report was cancelled. "
                    "Press **Report Score** to start again.", ephemeral=True,
                )

            attachment = next(a for a in message.attachments if _is_image(a))
            suffix = "." + attachment.filename.rsplit(".", 1)[-1].lower() if "." in attachment.filename else ".png"
            path = config.SCREENSHOT_DIR / f"match_{self.match_id}_{int(time.time())}{suffix}"
            path.parent.mkdir(parents=True, exist_ok=True)
            await attachment.save(path)

            m = await db.get_match(self.match_id)  # the match may have changed while we waited
            if not m or m["status"] != "pending" or m["reported_score"]:
                return await interaction.followup.send("The match changed while you were uploading. Please try again.", ephemeral=True)

            reporter_flag = "p1_confirmed" if reporter == m["player1_id"] else "p2_confirmed"
            await db.update_match(
                self.match_id, reported_score=f"{p1_score}-{p2_score}", p1_score=p1_score, p2_score=p2_score,
                reporter_id=reporter, screenshot_url=attachment.url, screenshot_path=str(path),
                p1_confirmed=0, p2_confirmed=0, ocr_confidence=None, ocr_score=None,
            )
            await db.update_match(self.match_id, **{reporter_flag: 1})
            m = await db.get_match(self.match_id)

            reporter_player, opponent_player = await db.get_player(reporter), await db.get_player(opponent)
            sent = await interaction.channel.send(
                matches.report_text(m, reporter_player["username"], opponent_player["username"]),
                view=ConfirmScoreView(bot),
            )
            await db.update_match(self.match_id, verify_message_id=sent.id)
            await db.add_log(self.match_id, f"{interaction.user} reported {mine}-{theirs}")
            await interaction.followup.send(
                f"Result submitted: {mine} - {theirs}. Waiting for <@{opponent}> to confirm.", ephemeral=True,
            )
        finally:
            bot.pending_reports.discard(self.match_id)


class CallAdminModal(SafeModal, title="Call Admin / Dispute"):
    reason = discord.ui.TextInput(
        label="Reason", placeholder="e.g. opponent AFK / didn't accept win / unfair play",
        min_length=3, max_length=300,
    )
    evidence = discord.ui.TextInput(
        label="Evidence / Note (optional)", style=discord.TextStyle.paragraph, required=False, max_length=800,
        placeholder="Anything that helps staff: what happened, times, links to screenshots...",
    )

    def __init__(self, bot, match_id: str):
        super().__init__()
        self.bot, self.match_id = bot, match_id

    async def on_submit(self, interaction: discord.Interaction) -> None:
        m = await self.bot.db.get_match(self.match_id)
        if not m or m["status"] in matches.CLOSED_STATUSES:
            return await reply(interaction, "This match is already closed.")
        if interaction.user.id not in (m["player1_id"], m["player2_id"]):
            return await reply(interaction, "Only the players can call staff from here.")
        sent = await matches.create_mod_request(
            self.bot, m, requester=interaction.user, reason=self.reason.value.strip(),
            evidence=(self.evidence.value or "").strip() or None,
        )
        if sent:
            await interaction.response.send_message(
                f"Moderator request sent for match {m['id']}. Staff have been alerted, sit tight."
            )
        else:
            await reply(interaction, "I couldn't reach the staff channel. Ping a moderator directly.")


class RejectModal(SafeModal, title="Reject Result"):
    reason = discord.ui.TextInput(
        label="Reason (shown to the players)", style=discord.TextStyle.paragraph,
        placeholder="e.g. the screenshot doesn't show the final score", min_length=3, max_length=500,
    )

    def __init__(self, bot, match_id: str):
        super().__init__()
        self.bot, self.match_id = bot, match_id

    async def on_submit(self, interaction: discord.Interaction) -> None:
        if not is_moderator(interaction):
            return await reply(interaction, NO_STAFF)
        m = await self.bot.db.get_match(self.match_id)
        if not m or m["status"] != "awaiting_admin":
            return await reply(interaction, "That result was already handled.")
        await matches.reject_result(self.bot, self.match_id, self.reason.value, interaction.user)
        message = interaction.message
        if message and message.embeds:
            embed = message.embeds[0]
            embed.title = "J21P Match Result Rejected"
            embed.color = discord.Color.red()
            embed.add_field(name="Rejected by", value=interaction.user.mention, inline=True)
            embed.add_field(name="Reason", value=self.reason.value[:1000], inline=False)
            await interaction.response.edit_message(embed=embed, view=_disabled_copy(AdminReviewView, self.bot))
        else:
            await reply(interaction, "Result rejected and the players were notified.")


# ===========================================================================
# Persistent views
# ===========================================================================
class MatchControlView(SafeView):
    """Buttons under the opening message of every match thread."""

    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="Send Match Code", style=discord.ButtonStyle.primary, custom_id="j21p:send_code", row=0)
    async def send_code(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        m = await _open_match(self.bot, interaction)
        if not m:
            return
        if interaction.user.id not in (m["player1_id"], m["player2_id"]):
            return await reply(interaction, "Only the players can send the match code.")
        await interaction.response.send_modal(SendCodeModal(self.bot, m["id"]))

    @discord.ui.button(label="Report Score", style=discord.ButtonStyle.success, custom_id="j21p:report_score", row=0)
    async def report_score(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        m = await _open_match(self.bot, interaction)
        if not m:
            return
        if interaction.user.id not in (m["player1_id"], m["player2_id"]):
            return await reply(interaction, "Only the players can report the score. Staff can use the Moderator Request buttons.")
        if m["status"] == "awaiting_admin":
            return await reply(interaction, "This result is already with staff.")
        if m["reported_score"]:
            return await reply(interaction, "A score is already waiting for confirmation.")
        await interaction.response.send_modal(ReportScoreModal(self.bot, m))

    @discord.ui.button(label="Call Admin / Dispute", style=discord.ButtonStyle.danger, custom_id="j21p:dispute", row=1)
    async def call_admin(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        m = await _open_match(self.bot, interaction)
        if not m:
            return
        if interaction.user.id not in (m["player1_id"], m["player2_id"]):
            return await reply(interaction, "Only the players can call staff from here.")
        await interaction.response.send_modal(CallAdminModal(self.bot, m["id"]))

    @discord.ui.button(label="Leave / Void Match", style=discord.ButtonStyle.secondary, custom_id="j21p:leave_void", row=1)
    async def leave_void(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        m = await _open_match(self.bot, interaction)
        if not m:
            return
        db, uid = self.bot.db, interaction.user.id

        if uid not in (m["player1_id"], m["player2_id"]):  # staff clicking the button
            await interaction.response.defer()
            await matches.void_match(self.bot, m["id"], interaction.user)
            return

        column = "cancel_p1" if uid == m["player1_id"] else "cancel_p2"
        if m[column]:
            return await reply(interaction, "You already asked to void this match. Your opponent or staff need to agree.")
        await db.update_match(m["id"], **{column: 1})
        m = await db.get_match(m["id"])
        if m["cancel_p1"] and m["cancel_p2"]:
            await interaction.response.defer()
            await matches.void_match(self.bot, m["id"], "mutual agreement of both players")
            return

        await interaction.response.send_message(
            f"{interaction.user.mention} wants to leave / void this match.\n"
            f"<@{opponent_of(m, uid)}> press **Leave / Void Match** to agree. Staff have also been alerted."
        )
        await matches.create_mod_request(
            self.bot, m, requester=interaction.user, reason="Requested to leave / void the match.",
        )


class ConfirmScoreView(SafeView):
    """Only two buttons under a reported score: Confirm (green) and Dispute (red)."""

    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    async def _current(self, interaction: discord.Interaction) -> dict | None:
        m = await self.bot.db.get_match_by_thread(interaction.channel_id)
        if not m or m["status"] != "pending" or not m["reported_score"]:
            await reply(interaction, "This report is no longer active.")
            return None
        if interaction.message.id != m["verify_message_id"]:
            await reply(interaction, "That report is out of date. Use the latest one.")
            return None
        if interaction.user.id not in (m["player1_id"], m["player2_id"]):
            await reply(interaction, "Only the two players in this match can use these buttons.")
            return None
        return m

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.success, custom_id="j21p:confirm_score")
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        m = await self._current(interaction)
        if not m:
            return
        if interaction.user.id == m["reporter_id"]:
            return await reply(interaction, "You reported this score. Your opponent needs to confirm it.")
        await self.bot.db.update_match(m["id"], p1_confirmed=1, p2_confirmed=1)
        await interaction.response.edit_message(
            content=f"{interaction.message.content}\n\nConfirmed by {interaction.user.mention}.",
            view=_disabled_copy(ConfirmScoreView, self.bot),
        )
        await matches.process_confirmed(self.bot, m["id"])

    @discord.ui.button(label="Dispute", style=discord.ButtonStyle.danger, custom_id="j21p:dispute_score")
    async def dispute(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        m = await self._current(interaction)
        if not m:
            return
        db = self.bot.db

        if interaction.user.id == m["reporter_id"]:  # the reporter backing out of their own report
            await matches.reset_report(self.bot, m["id"])
            await db.add_log(m["id"], f"Report withdrawn by {interaction.user}")
            await interaction.response.edit_message(
                content=f"{interaction.message.content}\n\nWithdrawn by {interaction.user.mention}.",
                view=_disabled_copy(ConfirmScoreView, self.bot),
            )
            return await interaction.followup.send("Report withdrawn. Press **Report Score** to submit the correct one.")

        mine, theirs = matches.reporter_scores(m)
        await db.update_match(m["id"], status="awaiting_admin")
        await interaction.response.edit_message(
            content=f"{interaction.message.content}\n\nDisputed by {interaction.user.mention}. Moderators have been alerted.",
            view=_disabled_copy(ConfirmScoreView, self.bot),
        )
        await matches.create_mod_request(
            self.bot, m, requester=interaction.user,
            reason=f"Disputed the reported score ({mine} - {theirs} in favour of the reporter's order).",
        )


class AdminReviewView(SafeView):
    """Approve / Reject buttons on the #admin-verification embed."""

    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not is_moderator(interaction):
            await reply(interaction, NO_STAFF)
            return False
        return True

    async def _pending(self, interaction: discord.Interaction) -> dict | None:
        m = await self.bot.db.get_match_by_admin_msg(interaction.message.id)
        if not m:
            await reply(interaction, "I can't find a match for this message.")
            return None
        if m["status"] != "awaiting_admin":
            await reply(interaction, "This result has already been handled.")
            return None
        return m

    @discord.ui.button(label="Approve", style=discord.ButtonStyle.success, custom_id="j21p:admin_approve")
    async def approve(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        m = await self._pending(interaction)
        if not m:
            return
        await interaction.response.defer()
        try:
            await matches.finalize_match(self.bot, m["id"], approved_by=interaction.user)
        except MatchError as exc:
            return await interaction.followup.send(str(exc), ephemeral=True)
        embed = interaction.message.embeds[0]
        embed.title = "J21P Match Result Approved"
        embed.color = discord.Color.green()
        embed.add_field(name="Approved by", value=interaction.user.mention, inline=True)
        await interaction.edit_original_response(embed=embed, view=_disabled_copy(AdminReviewView, self.bot))

    @discord.ui.button(label="Reject", style=discord.ButtonStyle.danger, custom_id="j21p:admin_reject")
    async def reject(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        m = await self._pending(interaction)
        if m:
            await interaction.response.send_modal(RejectModal(self.bot, m["id"]))


class CoachAlertView(SafeView):
    """The four resolution buttons under a Moderator Request in #coach-alerts."""

    def __init__(self, bot, p1_name: str = "Player 1", p2_name: str = "Player 2"):
        super().__init__(timeout=None)
        self.bot = bot
        self.award_p1.label = f"Award win to {p1_name}"[:80]
        self.award_p2.label = f"Award win to {p2_name}"[:80]

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not is_moderator(interaction):
            await reply(interaction, NO_STAFF)
            return False
        return True

    async def _match(self, interaction: discord.Interaction) -> dict | None:
        text = interaction.message.embeds[0].footer.text if interaction.message.embeds and interaction.message.embeds[0].footer else ""
        found = MATCH_ID_RE.search(text or "")
        m = await self.bot.db.get_match(found.group(0)) if found else None
        if not m:
            await reply(interaction, "I can't find the match for this request.")
            return None
        return m

    async def _resolve(self, interaction: discord.Interaction, outcome: str, color: discord.Color) -> None:
        embed = interaction.message.embeds[0]
        embed.color = color
        embed.add_field(name="Resolved", value=f"{outcome}\nBy {interaction.user.mention}", inline=False)
        await interaction.edit_original_response(embed=embed, view=_disabled_from_message(interaction.message))

    async def _award(self, interaction: discord.Interaction, side: int) -> None:
        m = await self._match(interaction)
        if not m:
            return
        if m["status"] == "completed" or (m["status"] == "voided" and m["match_type"] == "ladder"):
            return await reply(interaction, f"Match {m['id']} is already closed.")
        winner_id = m["player1_id"] if side == 1 else m["player2_id"]
        await interaction.response.defer()
        try:
            await matches.award_win(self.bot, m["id"], winner_id, interaction.user)
        except MatchError as exc:
            return await interaction.followup.send(str(exc), ephemeral=True)
        winner = await self.bot.db.get_player(winner_id)
        await self._resolve(interaction, f"Win awarded to {winner['username']}", discord.Color.green())

    @discord.ui.button(label="Award win to Player 1", style=discord.ButtonStyle.success, custom_id="j21p:alert_win_p1")
    async def award_p1(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._award(interaction, 1)

    @discord.ui.button(label="Award win to Player 2", style=discord.ButtonStyle.primary, custom_id="j21p:alert_win_p2")
    async def award_p2(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._award(interaction, 2)

    @discord.ui.button(label="Void match (no result)", style=discord.ButtonStyle.secondary, custom_id="j21p:alert_void")
    async def void(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        m = await self._match(interaction)
        if not m:
            return
        if m["status"] in matches.CLOSED_STATUSES:
            return await reply(interaction, f"Match {m['id']} is already closed.")
        await interaction.response.defer()
        await matches.void_match(self.bot, m["id"], interaction.user)
        await self._resolve(interaction, "Match voided, no result recorded", discord.Color.light_grey())

    @discord.ui.button(label="Dismiss", style=discord.ButtonStyle.secondary, custom_id="j21p:alert_dismiss")
    async def dismiss(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        m = await self._match(interaction)
        if not m:
            return
        await interaction.response.defer()
        # A dismissed score dispute goes back to the players so they can report again.
        if m["status"] == "awaiting_admin" and not m["admin_message_id"]:
            await matches.reset_report(self.bot, m["id"])
            thread = await matches.get_thread(self.bot, m["thread_id"])
            if thread:
                await thread.send(
                    f"Staff dismissed the dispute on match {m['id']}. "
                    f"<@{m['player1_id']}> <@{m['player2_id']}> press **Report Score** to submit the result again."
                )
        await self.bot.db.add_log(m["id"], f"Moderator request dismissed by {interaction.user}")
        await self._resolve(interaction, "Dismissed", discord.Color.light_grey())


class MatchThreadCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self) -> None:
        self.timer_loop.start()

    async def cog_unload(self) -> None:
        self.timer_loop.cancel()

    # --- typed room codes ----------------------------------------------------
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if message.author.bot or not isinstance(message.channel, discord.Thread):
            return
        if not matches.CODE_RE.match(message.content.strip()):
            return
        m = await self.bot.db.get_match_by_thread(message.channel.id)
        if not m or m["status"] != "pending":
            return
        if message.author.id not in (m["player1_id"], m["player2_id"]):
            return
        first = await matches.record_code(self.bot, m, message.content.strip())
        await message.reply(
            matches.code_recorded_text(m, first, opponent_of(m, message.author.id)),
            mention_author=False,
        )

    # --- 8 minute / 48 hour / 24 hour timers --------------------------------
    @tasks.loop(seconds=config.TIMER_CHECK_SECONDS)
    async def timer_loop(self) -> None:
        now = time.time()
        for m in await self.bot.db.timer_matches():
            try:
                for event in matches.timer_events(m, now):
                    await matches.run_timer_event(self.bot, m, event)
            except Exception:
                log.exception("Timer check failed for match %s", m["id"])

    @timer_loop.before_loop
    async def before_timer_loop(self) -> None:
        await self.bot.wait_until_ready()


async def setup(bot) -> None:
    await bot.add_cog(MatchThreadCog(bot))
