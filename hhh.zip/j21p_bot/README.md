# J21P 1v1 & Tournament Bot

FC Mobile 1v1 ladder and 32-player tournament bot for Discord. Two slash commands, everything else is buttons, dropdowns and modals.

Made with love by Clairy J21P, Aymtzs and Philosopher Dingleberry.

## Layout

```
j21p_bot/
  main.py                 bot entry point, loads the cogs, syncs slash commands
  config.py               reads .env, branding, points, OCR settings
  requirements.txt
  .env.example
  cogs/
    player_hub.py         /player_hub: Register, Join/Leave Queue, standings dropdown
    match_thread.py       thread buttons, room codes, score confirmation, #coach-alerts, timers
    admin_panel.py        /admin_panel: tournament + dispute dropdowns (per role tier), player import/export
    maintenance.py        scheduled backups, cleanup, stale queue entries
  database/
    database.py           aiosqlite schema and queries
  utils/
    matches.py            threads, score validation, OCR decision, finalizing results
    tournament.py         groups, knockout bracket, byes, admin overrides
    importer.py           parse and match a pasted tournament username list, CSV export
    avatars.py            cached avatar download for the standings images
    ocr.py                scoreline reader (pytesseract or EasyOCR)
    graphics.py           Pillow renderers + template generator
    checks.py             role tiers and channel lookups
    ui.py                 shared view/modal helpers
  templates/              groups_template.png, leaderboard_template.png
  assets/                 J21P logo and bundled Inter fonts
  data/                   created at runtime: sqlite db, backups, logs, screenshots, avatar cache
```

## Setup

1. Python 3.10 or newer.
2. `pip install -r requirements.txt`
3. Install the Tesseract program (needed by pytesseract):
   - Windows: installer from https://github.com/UB-Mannheim/tesseract/wiki, then add it to PATH
   - macOS: `brew install tesseract`
   - Debian/Ubuntu: `sudo apt install tesseract-ocr`
4. Copy `.env.example` to `.env` and fill in `DISCORD_TOKEN`, `GUILD_ID` and your admin role.
5. In the Discord developer portal create the bot and invite it with the `bot` and `applications.commands` scopes. Turn on the **Message Content Intent** and **Server Members Intent** (Bot tab). Without them the bot still runs, but typed room codes are not detected and name matching in imports is limited.
6. `python main.py`

### Permissions

In the hub channel, `#admin-verification` and `#coach-alerts` the bot needs: View Channel, Send Messages, Embed Links, Attach Files, Create Private Threads, Send Messages in Threads, Manage Threads, Read Message History.

## Roles

Hardcoded in `config.py` (cumulative, each tier includes the ones below it):

| Tier | Roles | Can do |
| --- | --- | --- |
| Executive | Owner, Co-Owner, Head Manager, Manager, Head Admin, Admin | everything: post `/player_hub`, Force Match Result, Fresh Start (wipe) |
| Event Manager | Event Manager (+ executives) | start group stage / knockout, manual threads, eliminate / reinstate / advance |
| Moderation | Head Moderator, Senior Moderator, Moderator, Trial Moderator, Helper, Staff Team (+ above) | `#coach-alerts` buttons, Approve / Reject scores, void matches, pending matches, find thread, log, archive |
| Player | Tournament Participants | given automatically when someone registers |

The server owner and anyone with the Administrator permission count as Executive. `/admin_panel` only shows each person the options their tier allows. The bot's own role must be above Tournament Participants so it can assign it.

## First run

1. Make a text channel for the hub and run `/player_hub` in it (executives only). That posts the panel and remembers the channel. All match threads are created there.
2. Make `#admin-verification` (OCR results that need a check) and `#coach-alerts` (moderator requests), or set their IDs in `.env`.
3. Players press Register (FC Mobile username + Team OVR), then Join 1v1 Queue.
4. Staff run `/admin_panel`.
5. Turn on the **Message Content Intent** for the bot in the Discord developer portal. It is needed to spot room codes typed in match threads.

## How a match works

Every match gets an 8 character hex ID (like `37FE4BD4`) and a private thread named `match-{p1}-{p2}`. The thread opens with the short "Match Started" message and four buttons: Send Match Code, Report Score, Call Admin / Dispute, Leave / Void Match.

1. **Room code.** Either press Send Match Code, or just type the 6 digit number in the thread. The bot saves it, replies "Code recorded for match ID" and pings the opponent.
2. **Timers.**
   - 1v1 queue: Player 1 is the match creator and has 8 minutes to post a room code. If not, the thread is warned and `#coach-alerts` is pinged.
   - Tournament: a 48 hour total timer starts when the thread is created. Once someone posts a room code, a 24 hour active timer takes over. Reminders go out at 12 hours and 2 hours left, and staff are alerted when a timer runs out.
3. **Score.** Report Score opens a modal for the score, then the bot waits 3 minutes for the screenshot in the thread. The reporter gets a private "Result submitted" message, and the opponent is pinged with two buttons only: Confirm (green) and Dispute (red).
4. **Confirm** runs the OCR. If it reads the same score above `OCR_CONFIDENCE_THRESHOLD` and `AUTO_APPROVE=true`, the result is applied straight away. Otherwise it goes to `#admin-verification` with Approve / Reject. Best-of-3 series always go to staff.
5. **Dispute**, **Call Admin** and **Leave / Void** (when one player asks) all send an orange Moderator Request to `#coach-alerts` pinging the Staff Team role, with four buttons: Award win to each player, Void match (no result), Dismiss.
6. **Void** posts "Match ID between A and B was voided - No result recorded." and "Match voided by staff. No result recorded.", then locks the thread. When both players press Leave / Void, it voids by mutual agreement. A voided tournament fixture still has to be settled by staff (Award win or Force Match Result) before the knockout can start.
7. **Award win** records a 3-0 walkover (2-0 in a Best-of-3).

## Tournament

- Start Group Stage / Auto-Create Threads: shuffles registered players into groups of 4 (up to 8 groups, 32 players), creates every round-robin fixture and opens the threads. Running it again only retries threads that failed.
- Group points: win = 3 (`GROUP_WIN_POINTS`). Table order: points, goal difference, goals for, wins.
- Start Knockout Bracket: once every group match is finished, takes the top 2 of each group (or the players you marked qualified) and builds the 16 player Best-of-3 bracket. Group winners face runners-up from the neighbouring group. With fewer than 32 players the missing spots become byes.
- Set Qualified / Advance Player Stage: during groups it marks a player qualified (if you mark anyone, only marked players enter the bracket). During the knockout it advances that player past their current match and closes the thread.
- Eliminate / Reinstate Player, Create Manual Match Thread, Fresh Start (keeps registrations and the ladder).
- Force Match / Bo3 Series Result (executives): modal with the 8 character match ID and a score like `2-1`, ordered Player 1 first (see View Pending Matches for who is Player 1).

## Importing the tournament player list

`/admin_panel` > Tournament Management > **Import Player List** (Event Manager and above). Paste one player per line:

```
L10NER, 126
Aymtzs | 130 | @Aymtzs
Philosopher Dingleberry - 118
Clairy, 140, 123456789012345678
```

Each line is an FC Mobile username, plus optionally a Team OVR (100-999) and an @mention or Discord ID. Commas, tabs, pipes, semicolons and " - " all work, and a CSV header row or numbering ("1. name") is ignored. The bot matches each name to a server member (ID, then exact name / nickname, then a single unambiguous partial match), shows a preview with anything it could not match, and imports only after you confirm. Imported players get the Tournament Participants role. Re-importing updates people instead of duplicating them. Imports are blocked once the group stage has started. **Export Player List (CSV)** downloads everyone registered.

## Graphics

The ladder leaderboard (top 20) and the tournament groups (A to H) are drawn with Pillow on `templates/leaderboard_template.png` and `templates/groups_template.png`. Each row shows the player's Discord avatar and username, with the J21P logo top left and the credit line at the bottom. Avatars are cached for 6 hours; a player with no avatar gets an initial letter. Drop your own artwork into `templates/` using the same file names, or run `python -m utils.graphics` to regenerate the defaults. There is no bracket image: the knockout still runs, it just is not drawn. Fonts are bundled (Inter) with automatic fallback for CJK, Arabic and Cyrillic names.

## Running in production

- **Database**: one SQLite file (`data/j21p.sqlite3`, WAL mode) with a lock plus transactions around every change, schema versioning, a unique FC username index and atomic claims so double clicks cannot double count a result. It is integrity-checked on start; a damaged file is moved aside and the newest backup is restored.
- **Backups**: `data/backups/` gets a consistent snapshot every `BACKUP_INTERVAL_HOURS` (newest `BACKUP_KEEP` kept).
- **Logs**: `data/logs/bot.log`, rotated.
- **Cleanup**: old screenshots and cached avatars are deleted automatically; players are dropped from the queue after 30 minutes.
- **Docker**: `docker compose up -d --build` (uses `.env`, data in `./data`). **systemd**: see `j21p-bot.service`.
- The bot never pings @everyone/@here, and player names are escaped before they are shown.

## Settings worth knowing

| Variable | What it does |
| --- | --- |
| `OCR_BACKEND` | `tesseract` (default) or `easyocr` (install `easyocr` first) |
| `OCR_CONFIDENCE_THRESHOLD` | below this the admin queue is always used |
| `AUTO_APPROVE` | set `false` to send every result to the admin queue |
| `LADDER_WIN_POINTS`, `GROUP_WIN_POINTS` | in `config.py` |

## Notes

The OCR was tested on synthetic score screens. Try it on real FC Mobile screenshots and lower or raise the threshold to taste; anything it cannot read just goes to the admin queue.

## Upgrading from the first version

Match IDs changed from numbers to hex. On first start, a database in the old layout is moved aside (`j21p.sqlite3.old-<time>`) and a fresh one is created, so old matches are not carried over. Players need to register again to enter their Team OVR.
