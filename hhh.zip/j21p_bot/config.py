"""Central configuration for the J21P bot. Secrets and channel IDs come from the .env file."""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _int(name: str, default: int | None = None) -> int | None:
    value = os.getenv(name, "").strip()
    return int(value) if value.isdigit() else default


def _bool(name: str, default: bool) -> bool:
    value = os.getenv(name, "").strip().lower()
    if not value:
        return default
    return value in {"1", "true", "yes", "on"}


# --- Discord ---------------------------------------------------------------
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
GUILD_ID = _int("GUILD_ID")

# Channels: set an ID, or leave blank and the bot finds a text channel by name.
ADMIN_VERIFICATION_CHANNEL_ID = _int("ADMIN_VERIFICATION_CHANNEL_ID")
ADMIN_VERIFICATION_CHANNEL_NAME = os.getenv("ADMIN_VERIFICATION_CHANNEL_NAME", "admin-verification").strip()
COACH_ALERTS_CHANNEL_ID = _int("COACH_ALERTS_CHANNEL_ID")
COACH_ALERTS_CHANNEL_NAME = os.getenv("COACH_ALERTS_CHANNEL_NAME", "coach-alerts").strip()
MATCH_CHANNEL_ID = _int("MATCH_CHANNEL_ID")

# --- Roles (hardcoded) -------------------------------------------------------
ROLE_OWNER = 1560669304913928303
ROLE_CO_OWNER = 1560669304913928295
ROLE_HEAD_MANAGER = 1560669304905535628
ROLE_MANAGER = 1560669304905535626
ROLE_HEAD_ADMIN = 1560669304905535625
ROLE_ADMIN = 1560669304905535624

ROLE_EVENT_MANAGER = 1560669304897278025

ROLE_HEAD_MODERATOR = 1560669304905535622
ROLE_SENIOR_MODERATOR = 1560669304905535621
ROLE_MODERATOR = 1560669304905535620
ROLE_TRIAL_MODERATOR = 1560669304905535619
ROLE_HELPER = 1560669304897278031
ROLE_STAFF_TEAM = 1560669304897278030

ROLE_PARTICIPANT = 1560669304436039703  # "Tournament Participants", given on registration

# Executive: wipe data, force results, manage every panel.
EXECUTIVE_ROLE_IDS = frozenset({
    ROLE_OWNER, ROLE_CO_OWNER, ROLE_HEAD_MANAGER, ROLE_MANAGER, ROLE_HEAD_ADMIN, ROLE_ADMIN,
})
# Tournament management: start stages, manual threads, advance / eliminate players.
EVENT_MANAGER_ROLE_IDS = frozenset({ROLE_EVENT_MANAGER}) | EXECUTIVE_ROLE_IDS
# Moderation: coach-alerts, approve / reject scores, void matches.
MODERATION_ROLE_IDS = frozenset({
    ROLE_HEAD_MODERATOR, ROLE_SENIOR_MODERATOR, ROLE_MODERATOR, ROLE_TRIAL_MODERATOR,
    ROLE_HELPER, ROLE_STAFF_TEAM,
}) | EVENT_MANAGER_ROLE_IDS

# --- Branding --------------------------------------------------------------
BRAND_NAME = "J21P"
BRAND_COLOR = 0x00B0FF
ALERT_COLOR = 0xE67E22
CREDITS = "Made with love by Clairy J21P, Aymtzs and Philosopher Dingleberry"
BRAND_FOOTER = f"J21P 1v1 & Tournament Hub | {CREDITS}"

# --- Gameplay --------------------------------------------------------------
LADDER_WIN_POINTS = 3       # ladder points for a 1v1 ladder win
GROUP_WIN_POINTS = 3        # group-stage points for a win
LADDER_LEADERBOARD_SIZE = 20   # rows on the leaderboard image (max 20)
AWARD_SCORE_SINGLE = (3, 0)  # walkover score when staff award a single game
AWARD_SCORE_BO3 = (2, 0)     # walkover score when staff award a Best-of-3 series
OVR_MIN, OVR_MAX = 100, 999  # Team OVR is a 3-digit number
TOURNAMENT_MAX_PLAYERS = 32  # 8 groups of 4
USERNAME_MIN, USERNAME_MAX = 2, 24
QUEUE_EXPIRY_MINUTES = 30    # players are dropped from the 1v1 queue after this long

# --- Timers ----------------------------------------------------------------
QUEUE_CREATOR_MINUTES = 8        # 1v1 queue: Player 1 must post a room code in this time
TOURNAMENT_TOTAL_HOURS = 48      # tournament: total time from thread creation
TOURNAMENT_ACTIVE_HOURS = 24     # tournament: time to finish once a room code is posted
TIMER_CHECK_SECONDS = 60

# --- OCR -------------------------------------------------------------------
OCR_BACKEND = os.getenv("OCR_BACKEND", "tesseract").strip().lower()
OCR_CONFIDENCE_THRESHOLD = float(os.getenv("OCR_CONFIDENCE_THRESHOLD", "80") or 80)
AUTO_APPROVE = _bool("AUTO_APPROVE", True)
# A single screenshot cannot prove a whole Best-of-3 series, so those always go to an admin.
BO3_ALWAYS_ADMIN = True

# --- Paths -----------------------------------------------------------------
DATA_DIR = Path(os.getenv("DATA_DIR", "").strip() or BASE_DIR / "data")
DB_PATH = DATA_DIR / "j21p.sqlite3"
SCREENSHOT_DIR = DATA_DIR / "screenshots"
AVATAR_DIR = DATA_DIR / "avatars"
BACKUP_DIR = DATA_DIR / "backups"
LOG_DIR = DATA_DIR / "logs"
TEMPLATES_DIR = BASE_DIR / "templates"
ASSETS_DIR = BASE_DIR / "assets"
FONT_PATH = os.getenv("FONT_PATH", "").strip()

# --- Maintenance ---------------------------------------------------------------
BACKUP_INTERVAL_HOURS = float(os.getenv("BACKUP_INTERVAL_HOURS", "6") or 6)
BACKUP_KEEP = int(os.getenv("BACKUP_KEEP", "20") or 20)
SCREENSHOT_RETENTION_DAYS = int(os.getenv("SCREENSHOT_RETENTION_DAYS", "45") or 45)
AVATAR_TTL_HOURS = 6
MAX_SCREENSHOT_BYTES = 10 * 1024 * 1024
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").strip().upper() or "INFO"
