"""J21P 1v1 & Tournament Bot.

Made with love by Clairy J21P, Aymtzs and Philosopher Dingleberry.
"""
from __future__ import annotations

import asyncio
import logging
import logging.handlers
import sys

import discord
from discord import app_commands
from discord.ext import commands

import config
from cogs.match_thread import AdminReviewView, CoachAlertView, ConfirmScoreView, MatchControlView
from cogs.player_hub import HubView
from database.database import Database
from utils.graphics import ensure_templates



def setup_logging() -> None:
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    root = logging.getLogger()
    root.setLevel(getattr(logging, config.LOG_LEVEL, logging.INFO))
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(fmt)
    root.addHandler(console)
    try:
        config.LOG_DIR.mkdir(parents=True, exist_ok=True)
        file_handler = logging.handlers.RotatingFileHandler(
            config.LOG_DIR / "bot.log", maxBytes=2_000_000, backupCount=5, encoding="utf-8")
        file_handler.setFormatter(fmt)
        root.addHandler(file_handler)
    except OSError:
        pass
    logging.getLogger("discord").setLevel(logging.WARNING)
    logging.getLogger("PIL").setLevel(logging.WARNING)


log = logging.getLogger("j21p")

EXTENSIONS = ("cogs.player_hub", "cogs.match_thread", "cogs.admin_panel", "cogs.maintenance")


class J21PBot(commands.Bot):
    def __init__(self, privileged: bool = True) -> None:
        intents = discord.Intents.default()
        if privileged:
            intents.message_content = True  # spots 6-digit room codes typed in match threads
            intents.members = True          # lets the player import match names to members
        self.privileged = privileged
        super().__init__(
            command_prefix=commands.when_mentioned,
            intents=intents,
            help_command=None,
            allowed_mentions=discord.AllowedMentions(everyone=False, users=True, roles=True, replied_user=False),
            max_messages=None,
        )
        self.db = Database(config.DB_PATH, config.BACKUP_DIR)
        self.queue_lock = asyncio.Lock()
        self.pending_reports: set[str] = set()

    async def setup_hook(self) -> None:
        config.DATA_DIR.mkdir(parents=True, exist_ok=True)
        for folder in (config.SCREENSHOT_DIR, config.AVATAR_DIR, config.BACKUP_DIR, config.LOG_DIR):
            folder.mkdir(parents=True, exist_ok=True)
        await self.db.connect()
        if self.db.corrupt_moved:
            log.error("Database was damaged. Moved to %s. Restored from backup: %s",
                      self.db.corrupt_moved, self.db.restored_from or "none, started fresh")
        if self.db.migrated_from:
            log.warning("Old database layout found. Moved it to %s and started a fresh one.", self.db.migrated_from)
        ensure_templates()

        for extension in EXTENSIONS:
            await self.load_extension(extension)

        # Every persistent view is registered here so buttons keep working after a restart.
        for view in (
            HubView(self),
            MatchControlView(self),
            ConfirmScoreView(self),
            AdminReviewView(self),
            CoachAlertView(self),
        ):
            self.add_view(view)

        if config.GUILD_ID:
            guild = discord.Object(id=config.GUILD_ID)
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
            log.info("Slash commands synced to guild %s", config.GUILD_ID)
        else:
            await self.tree.sync()
            log.info("Slash commands synced globally (can take up to an hour to appear)")

    async def on_ready(self) -> None:
        log.info("Logged in as %s (%s)", self.user, self.user.id if self.user else "?")
        log.info(config.CREDITS)
        if not self.privileged:
            log.warning("Running without the Message Content / Server Members intents. Typed room codes are not "
                        "detected (use the Send Match Code button) and name matching in imports is limited. "
                        "Enable both intents in the Developer Portal for the full feature set.")

    async def close(self) -> None:
        await self.db.close()
        await super().close()


async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.CheckFailure):
        text = "You can't use that command here."
        try:
            if interaction.response.is_done():
                await interaction.followup.send(text, ephemeral=True)
            else:
                await interaction.response.send_message(text, ephemeral=True)
        except discord.HTTPException:
            pass
        return
    log.exception("Slash command error", exc_info=error)
    message = "Something went wrong running that command."
    try:
        if interaction.response.is_done():
            await interaction.followup.send(message, ephemeral=True)
        else:
            await interaction.response.send_message(message, ephemeral=True)
    except discord.HTTPException:
        pass


async def run_bot(privileged: bool) -> None:
    bot = J21PBot(privileged)
    bot.tree.error(on_app_command_error)
    async with bot:
        await bot.start(config.TOKEN)


def main() -> None:
    setup_logging()
    if not config.TOKEN:
        raise SystemExit("DISCORD_TOKEN is missing. Copy .env.example to .env and fill it in.")
    try:
        try:
            asyncio.run(run_bot(True))
        except discord.PrivilegedIntentsRequired:
            log.warning("Privileged intents are not enabled in the Developer Portal. Starting without them.")
            asyncio.run(run_bot(False))
    except discord.LoginFailure:
        raise SystemExit("Discord rejected the token. Check DISCORD_TOKEN in .env.")
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
